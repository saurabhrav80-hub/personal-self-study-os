import { useMemo, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { EmptyState, Screen } from "@/components/ui/empty";
import { Input } from "@/components/ui/input";
import {
  useConceptLinks,
  useConcepts,
  useKnowledgeMap,
  useMistakes,
  useQuestions,
  useRevisions,
} from "@/lib/study/hooks";

export function ConceptsPage() {
  const concepts = useConcepts();
  const links = useConceptLinks();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const shown = concepts.filter((c) => {
    const hay = `${c.name} ${c.aliases.join(" ")} ${c.summary}`.toLowerCase();
    return !q || hay.includes(q.toLowerCase());
  });

  const width = 320;
  const height = 280;
  const layout = useMemo(() => {
    return shown.slice(0, 16).map((c, i, arr) => {
      const angle = (i / Math.max(arr.length, 1)) * Math.PI * 2 - Math.PI / 2;
      const r = 110;
      return { ...c, x: width / 2 + Math.cos(angle) * r, y: height / 2 + Math.sin(angle) * r };
    });
  }, [shown]);

  return (
    <Screen title="Concept map">
      <p className="mb-3 text-sm text-muted">
        Knowledge is linked across exams — percentage is not only CAT, duration is not only CFA.
      </p>
      <Input placeholder="Search concepts" value={q} onChange={(e) => setQ(e.target.value)} />
      {concepts.length === 0 ? (
        <EmptyState className="mt-6" title="No concepts" body="Starter concepts load on first launch." />
      ) : (
        <>
          <Card className="mt-4 overflow-hidden p-0">
            <svg viewBox={`0 0 ${width} ${height}`} className="w-full">
              {links.map((l) => {
                const a = layout.find((n) => n.id === l.fromId);
                const b = layout.find((n) => n.id === l.toId);
                if (!a || !b) return null;
                return (
                  <line key={l.id} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="currentColor" className="text-border" />
                );
              })}
              {layout.map((n) => (
                <g
                  key={n.id}
                  className="cursor-pointer"
                  onClick={() => navigate({ to: "/concepts/$conceptId", params: { conceptId: n.id } })}
                >
                  <circle cx={n.x} cy={n.y} r="18" className="fill-surface-2 stroke-ink" />
                  <text x={n.x} y={n.y + 32} textAnchor="middle" className="fill-fg" fontSize="9">
                    {n.name.split(" ")[0]}
                  </text>
                </g>
              ))}
            </svg>
          </Card>
          <ul className="mt-4 space-y-2">
            {shown.map((c) => (
              <li key={c.id}>
                <Link
                  to="/concepts/$conceptId"
                  params={{ conceptId: c.id }}
                  className="block rounded-2xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]"
                >
                  <p className="font-medium">{c.name}</p>
                  <p className="text-xs text-muted">{c.summary}</p>
                </Link>
              </li>
            ))}
          </ul>
        </>
      )}
    </Screen>
  );
}

export function ConceptDetailPage({ conceptId }: { conceptId: string }) {
  const concepts = useConcepts();
  const links = useConceptLinks();
  const questions = useQuestions();
  const mistakes = useMistakes();
  const revisions = useRevisions();
  const knowledge = useKnowledgeMap();
  const c = concepts.find((x) => x.id === conceptId);
  if (!c) {
    return (
      <Screen title="Concept">
        <p className="text-muted">Not found.</p>
      </Screen>
    );
  }
  const related = links
    .filter((l) => l.fromId === c.id || l.toId === c.id)
    .map((l) => concepts.find((x) => x.id === (l.fromId === c.id ? l.toId : l.fromId)))
    .filter(Boolean);
  const qs = questions.filter((q) => q.topicId && c.topicIds.includes(q.topicId));
  const ms = mistakes.filter((m) => m.topicId && c.topicIds.includes(m.topicId));
  const rs = revisions.filter((r) => r.topicId && c.topicIds.includes(r.topicId));
  const k = c.topicIds.length
    ? Math.round(c.topicIds.reduce((s, id) => s + (knowledge[id] ?? 0), 0) / c.topicIds.length)
    : 0;

  return (
    <Screen title={c.name}>
      <p className="text-sm text-muted">{c.summary}</p>
      <div className="mt-4 grid grid-cols-2 gap-2">
        <Stat l="Questions" n={qs.length} />
        <Stat l="Mistakes" n={ms.length} />
        <Stat l="Revision cards" n={rs.length} />
        <Stat l="Knowledge" n={`${k}%`} />
      </div>
      <p className="mt-5 text-xs tracking-wide text-subtle uppercase">Related</p>
      <ul className="mt-2 space-y-1">
        {related.map((r) =>
          r ? (
            <li key={r.id}>
              <Link to="/concepts/$conceptId" params={{ conceptId: r.id }} className="text-sm">
                {r.name}
              </Link>
            </li>
          ) : null,
        )}
      </ul>
      {c.topicIds[0] ? (
        <Link
          className="mt-6 inline-block text-sm"
          to="/practice/run"
          search={{ mode: "topic", topicId: c.topicIds[0] }}
        >
          Practice this concept
        </Link>
      ) : null}
    </Screen>
  );
}

function Stat({ l, n }: { l: string; n: number | string }) {
  return (
    <Card className="p-3">
      <p className="text-[11px] text-muted">{l}</p>
      <p className="font-display text-2xl tabular">{n}</p>
    </Card>
  );
}
