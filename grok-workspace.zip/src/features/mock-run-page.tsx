import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { useMocks, useQuestions } from "@/lib/study/hooks";
import { recordAttempt, saveMockResult } from "@/lib/study/repo";
import { nid, numericalMatch } from "@/lib/utils";
import type { MockAnswer, Question } from "@/lib/study/types";

export function MockRunPage({ mockId }: { mockId: string }) {
  const mocks = useMocks();
  const questions = useQuestions();
  const mock = mocks.find((m) => m.id === mockId);
  const navigate = useNavigate();
  const paper = useMemo(() => {
    if (!mock) return [];
    const map = new Map(questions.map((q) => [q.id, q]));
    return mock.questionIds.map((id) => map.get(id)).filter((q): q is Question => !!q);
  }, [mock, questions]);

  const [idx, setIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, MockAnswer>>({});
  const [confirm, setConfirm] = useState(false);
  const [remaining, setRemaining] = useState((mock?.timeLimitMin ?? 20) * 60);
  const started = useRef(Date.now());
  const qStart = useRef(Date.now());
  const [section, setSection] = useState(0);
  const answersRef = useRef(answers);
  const paperRef = useRef(paper);
  const submitted = useRef(false);
  answersRef.current = answers;
  paperRef.current = paper;

  useEffect(() => {
    if (!mock) return;
    setRemaining(mock.timeLimitMin * 60);
    submitted.current = false;
  }, [mock?.id, mock?.timeLimitMin]);

  const finish = async (auto: boolean) => {
    if (!mock || submitted.current) return;
    submitted.current = true;
    const q = paperRef.current[idx];
    if (q) {
      const spent = Date.now() - qStart.current;
      const prev = answersRef.current;
      const cur = prev[q.id] ?? {
        questionId: q.id,
        answer: "",
        timeMs: 0,
        marked: false,
        skipped: true,
      };
      answersRef.current = { ...prev, [q.id]: { ...cur, timeMs: cur.timeMs + spent } };
    }
    const resultId = nid();
    const rows: MockAnswer[] = paperRef.current.map((item) => {
      const a = answersRef.current[item.id];
      return {
        questionId: item.id,
        answer: a?.answer ?? "",
        timeMs: a?.timeMs ?? 0,
        marked: a?.marked ?? false,
        skipped: !a?.answer,
      };
    });
    let score = 0;
    let correctN = 0;
    let attempted = 0;
    for (const row of rows) {
      const item = paperRef.current.find((p) => p.id === row.questionId);
      if (!item || row.skipped) continue;
      attempted += 1;
      const ok =
        item.type === "numerical" || item.type === "short"
          ? numericalMatch(row.answer, item.correctAnswer) ||
            row.answer.trim().toLowerCase() === item.correctAnswer.trim().toLowerCase()
          : row.answer === item.correctAnswer;
      if (ok) {
        score += mock.marksCorrect;
        correctN += 1;
      } else {
        score -= mock.negativeMarking;
      }
      await recordAttempt({
        question: item,
        answer: row.answer,
        correct: ok,
        confidence: null,
        timeMs: row.timeMs,
        mockResultId: resultId,
        mistakeCategory: ok ? null : "other",
      });
    }
    const maxScore = paperRef.current.length * mock.marksCorrect;
    const used = Date.now() - started.current;
    const allotted = mock.timeLimitMin * 60000;
    await saveMockResult({
      id: resultId,
      mockId: mock.id,
      startedAt: started.current,
      submittedAt: Date.now(),
      answers: rows,
      score,
      maxScore,
      accuracy: attempted ? (correctN / attempted) * 100 : 0,
      attemptRate: paperRef.current.length ? (attempted / paperRef.current.length) * 100 : 0,
      timeEfficiency: allotted ? Math.min(100, (used / allotted) * 100) : 0,
    });
    toast.success(auto ? "Time is up. Mock submitted." : "Mock submitted.");
    navigate({ to: "/mocks/report/$resultId", params: { resultId } });
  };

  useEffect(() => {
    const t = setInterval(() => {
      setRemaining((s) => {
        if (s <= 1) {
          clearInterval(t);
          void finish(true);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mock?.id]);

  if (!mock) {
    return <div className="flex min-h-dvh items-center justify-center text-muted">Mock not found.</div>;
  }

  const q = paper[idx];
  const mm = Math.floor(remaining / 60);
  const ss = String(remaining % 60).padStart(2, "0");

  const recordTime = (qid: string) => {
    const spent = Date.now() - qStart.current;
    setAnswers((prev) => {
      const cur = prev[qid] ?? {
        questionId: qid,
        answer: "",
        timeMs: 0,
        marked: false,
        skipped: true,
      };
      return { ...prev, [qid]: { ...cur, timeMs: cur.timeMs + spent } };
    });
    qStart.current = Date.now();
  };

  const setAns = (qid: string, value: string) => {
    setAnswers((prev) => ({
      ...prev,
      [qid]: {
        questionId: qid,
        answer: value,
        timeMs: prev[qid]?.timeMs ?? 0,
        marked: prev[qid]?.marked ?? false,
        skipped: !value,
      },
    }));
  };

  const sections = mock.sections.length
    ? mock.sections
    : [{ name: "All", questionIds: mock.questionIds, timeMin: mock.timeLimitMin }];

  return (
    <div className="flex min-h-dvh flex-col bg-bg">
      <header className="flex h-12 items-center justify-between border-b border-border px-3">
        <p className="truncate text-sm font-medium">{mock.name}</p>
        <p className="tabular font-display text-lg">
          {mm}:{ss}
        </p>
      </header>
      {sections.length > 1 ? (
        <div className="flex gap-1 overflow-x-auto border-b border-border px-2 py-2">
          {sections.map((s, i) => (
            <button
              key={s.name}
              type="button"
              onClick={() => {
                if (q) recordTime(q.id);
                setSection(i);
                const first = paper.findIndex((p) => s.questionIds.includes(p.id));
                if (first >= 0) setIdx(first);
              }}
              className={`h-9 shrink-0 rounded-full px-3 text-xs ${i === section ? "bg-ink text-paper" : "bg-surface-2"}`}
            >
              {s.name}
            </button>
          ))}
        </div>
      ) : null}

      <div className="flex-1 overflow-y-auto px-4 py-4">
        {q ? (
          <>
            <p className="text-xs text-muted">
              Q{idx + 1} of {paper.length}
            </p>
            <p className="mt-2 font-display text-xl leading-snug">{q.stem}</p>
            <div className="mt-4 space-y-2">
              {q.options.length ? (
                q.options.map((o) => (
                  <button
                    key={o.id}
                    type="button"
                    onClick={() => setAns(q.id, o.id)}
                    className={`flex min-h-12 w-full items-center rounded-2xl px-4 text-left text-sm ${
                      answers[q.id]?.answer === o.id
                        ? "bg-ink text-paper"
                        : "bg-surface shadow-[var(--shadow-border)]"
                    }`}
                  >
                    {o.text}
                  </button>
                ))
              ) : (
                <input
                  className="h-12 w-full rounded-2xl bg-surface px-4 shadow-[var(--shadow-border)]"
                  value={answers[q.id]?.answer ?? ""}
                  onChange={(e) => setAns(q.id, e.target.value)}
                  placeholder="Answer"
                />
              )}
            </div>
          </>
        ) : (
          <p className="text-muted">No questions on this paper.</p>
        )}
      </div>

      <div className="border-t border-border px-3 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
        <div className="mb-2 flex flex-wrap gap-1">
          {paper.map((item, i) => {
            const a = answers[item.id];
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  if (q) recordTime(q.id);
                  setIdx(i);
                }}
                className={`size-8 rounded-md text-xs ${
                  i === idx
                    ? "bg-ink text-paper"
                    : a?.marked
                      ? "bg-warn/30"
                      : a?.answer
                        ? "bg-good/25"
                        : "bg-surface-2"
                }`}
              >
                {i + 1}
              </button>
            );
          })}
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            className="flex-1"
            onClick={() => {
              if (!q) return;
              setAnswers((p) => ({
                ...p,
                [q.id]: {
                  questionId: q.id,
                  answer: p[q.id]?.answer ?? "",
                  timeMs: p[q.id]?.timeMs ?? 0,
                  marked: !p[q.id]?.marked,
                  skipped: !p[q.id]?.answer,
                },
              }));
            }}
          >
            Mark
          </Button>
          <Button
            variant="secondary"
            className="flex-1"
            disabled={idx <= 0}
            onClick={() => {
              if (q) recordTime(q.id);
              setIdx(idx - 1);
            }}
          >
            Prev
          </Button>
          <Button
            variant="secondary"
            className="flex-1"
            disabled={idx >= paper.length - 1}
            onClick={() => {
              if (q) recordTime(q.id);
              setIdx(idx + 1);
            }}
          >
            Next
          </Button>
          <Button
            className="flex-1"
            onClick={() => {
              if (!confirm) setConfirm(true);
              else void finish(false);
            }}
          >
            Submit
          </Button>
        </div>
      </div>

      {confirm ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/40 px-4">
          <div className="w-full max-w-sm rounded-2xl bg-surface p-5">
            <p className="font-display text-xl">Submit this mock?</p>
            <p className="mt-2 text-sm text-muted">
              Attempted {Object.values(answers).filter((a) => a.answer).length} of {paper.length}. This cannot be
              undone.
            </p>
            <div className="mt-4 flex gap-2">
              <Button variant="ghost" className="flex-1" onClick={() => setConfirm(false)}>
                Continue
              </Button>
              <Button className="flex-1" onClick={() => finish(false)}>
                Submit
              </Button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
