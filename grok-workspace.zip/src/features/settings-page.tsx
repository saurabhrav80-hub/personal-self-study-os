import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Field, Input, NativeSelect } from "@/components/ui/input";
import { Screen, SectionLabel } from "@/components/ui/empty";
import { exportBackup, importBackup } from "@/lib/study/backup";
import { requireDb } from "@/lib/study/db";
import { useAllExams, useReadiness, useSettingsLive } from "@/lib/study/hooks";
import { createExam, patchSettings, updateExam } from "@/lib/study/repo";
import { removeStarterQuestions } from "@/lib/study/seed";
import type { ThemeMode } from "@/lib/study/types";

export function SettingsPage() {
  const settings = useSettingsLive();
  const exams = useAllExams();
  const readiness = useReadiness();
  const [newExam, setNewExam] = useState("");
  const [includeFiles, setIncludeFiles] = useState(false);

  if (!settings) return <Screen title="Settings" />;

  const weights = settings.readinessWeights;
  const wsum = Object.values(weights).reduce((s, n) => s + n, 0);

  return (
    <Screen title="Profile">
      <SectionLabel>You</SectionLabel>
      <Field label="Display name">
        <Input
          defaultValue={settings.displayName}
          onBlur={(e) => patchSettings({ displayName: e.target.value })}
        />
      </Field>

      <SectionLabel>Appearance</SectionLabel>
      <div className="mb-6 grid grid-cols-3 gap-2">
        {(["light", "dark", "system"] as ThemeMode[]).map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => patchSettings({ theme: t })}
            className={`h-11 rounded-xl capitalize ${settings.theme === t ? "bg-ink text-paper" : "bg-surface shadow-[var(--shadow-border)]"}`}
          >
            {t}
          </button>
        ))}
      </div>

      <SectionLabel>Exams</SectionLabel>
      <ul className="mb-4 space-y-2">
        {exams.map((e) => (
          <li key={e.id}>
            <Card className="space-y-2 p-4">
              <div className="flex items-center justify-between">
                <input
                  className="bg-transparent font-medium outline-none"
                  defaultValue={e.name}
                  onBlur={(ev) => updateExam(e.id, { name: ev.target.value })}
                />
                <label className="flex items-center gap-2 text-xs text-muted">
                  Active
                  <input
                    type="checkbox"
                    checked={e.active}
                    onChange={(ev) => updateExam(e.id, { active: ev.target.checked })}
                  />
                </label>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Field label="Exam date">
                  <Input
                    type="date"
                    defaultValue={e.date ? new Date(e.date).toISOString().slice(0, 10) : ""}
                    onChange={(ev) =>
                      updateExam(e.id, { date: ev.target.value ? new Date(ev.target.value).getTime() : null })
                    }
                  />
                </Field>
                <Field label="Priority 1–5">
                  <Input
                    type="number"
                    min={1}
                    max={5}
                    defaultValue={e.priority}
                    onBlur={(ev) => updateExam(e.id, { priority: Number(ev.target.value) || 3 })}
                  />
                </Field>
                <Field label="Target score">
                  <Input
                    type="number"
                    defaultValue={e.targetScore ?? ""}
                    onBlur={(ev) =>
                      updateExam(e.id, { targetScore: ev.target.value ? Number(ev.target.value) : null })
                    }
                  />
                </Field>
                <Field label="Target time / Q (sec)">
                  <Input
                    type="number"
                    defaultValue={Math.round((settings.targetTimes[e.id] ?? 120000) / 1000)}
                    onBlur={(ev) =>
                      patchSettings({
                        targetTimes: {
                          ...settings.targetTimes,
                          [e.id]: Number(ev.target.value) * 1000,
                        },
                      })
                    }
                  />
                </Field>
              </div>
              {(() => {
                const r = readiness.find((x) => x.examId === e.id);
                if (!r) return null;
                return (
                  <p className="text-[11px] text-subtle">
                    Components — knowledge {dash(r.knowledge)}, accuracy {dash(r.accuracy)}, speed {dash(r.speed)},
                    retention {dash(r.retention)}, mock {dash(r.mock)}, coverage {dash(r.weak)}
                  </p>
                );
              })()}
            </Card>
          </li>
        ))}
      </ul>
      <div className="mb-6 flex gap-2">
        <Input placeholder="Add exam (GMAT, FRM, …)" value={newExam} onChange={(e) => setNewExam(e.target.value)} />
        <Button
          onClick={async () => {
            if (!newExam.trim()) return;
            await createExam({ name: newExam.trim() });
            setNewExam("");
          }}
        >
          Add
        </Button>
      </div>

      <SectionLabel>Readiness weights (must sum conceptually; currently {wsum})</SectionLabel>
      <div className="mb-6 grid grid-cols-2 gap-2">
        {(Object.keys(weights) as (keyof typeof weights)[]).map((k) => (
          <Field key={k} label={k}>
            <Input
              type="number"
              defaultValue={weights[k]}
              onBlur={(e) =>
                patchSettings({
                  readinessWeights: { ...weights, [k]: Number(e.target.value) || 0 },
                })
              }
            />
          </Field>
        ))}
      </div>

      <SectionLabel>Data</SectionLabel>
      <label className="mb-3 flex min-h-11 items-center gap-2 text-sm">
        <input type="checkbox" checked={includeFiles} onChange={(e) => setIncludeFiles(e.target.checked)} />
        Include PDF files in export (can be large)
      </label>
      <div className="mb-3 flex flex-wrap gap-2">
        <Button variant="outline" onClick={() => exportBackup(includeFiles)}>
          Export backup
        </Button>
        <label className="inline-flex h-11 items-center rounded-lg bg-surface-2 px-4 text-sm font-medium">
          Import backup
          <input
            type="file"
            accept="application/json"
            className="hidden"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              try {
                const r = await importBackup(f);
                toast.success(`Restored ${r.restored.join(", ") || "data"}.`);
              } catch (err) {
                toast.error(err instanceof Error ? err.message : "Import failed.");
              }
            }}
          />
        </label>
        <Button
          variant="ghost"
          onClick={async () => {
            if (!confirm("Remove starter questions from the bank?")) return;
            await removeStarterQuestions(requireDb());
            toast.success("Starter questions removed.");
          }}
        >
          Remove starter questions
        </Button>
      </div>

      <SectionLabel>Privacy</SectionLabel>
      <p className="text-sm text-muted">
        Core study data is stored in this browser (IndexedDB). No account is required. Uploaded books are not sent
        anywhere unless you explicitly run an AI action such as Ask My Books, which then sends only the matching
        excerpts you already searched locally.
      </p>
    </Screen>
  );
}

function dash(n: number | null) {
  return n == null ? "—" : `${n}%`;
}
