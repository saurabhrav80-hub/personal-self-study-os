import { useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { KnowledgeBar, StatusChip } from "@/components/status-chip";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { EmptyState, Screen } from "@/components/ui/empty";
import { Field, NativeSelect } from "@/components/ui/input";
import { generateChapterQuestions } from "@/lib/ai/study-ai";
import { requireDb } from "@/lib/study/db";
import { useBook, useChapters, useExams, useKnowledgeMap, useTopics } from "@/lib/study/hooks";
import { createQuestion, deleteBook, saveChapters, setTopicStatus } from "@/lib/study/repo";
import { nid } from "@/lib/utils";
import type { Chapter, Difficulty, Question } from "@/lib/study/types";

export function BookPage({ bookId }: { bookId: string }) {
  const book = useBook(bookId);
  const chapters = useChapters(bookId);
  const topics = useTopics({ bookId });
  const exams = useExams();
  const knowledge = useKnowledgeMap();
  const [aiOpen, setAiOpen] = useState<string | null>(null);
  const navigate = useNavigate();

  if (!book) {
    return (
      <Screen title="Book">
        <EmptyState title="Book not found" body="It may have been removed from this device." />
      </Screen>
    );
  }

  return (
    <Screen
      title={book.name}
      action={
        <Link to="/read/$bookId" params={{ bookId }}>
          <Button size="sm">Read</Button>
        </Link>
      }
    >
      <p className="mb-4 text-sm text-muted">
        {exams.find((e) => e.id === book.examId)?.name ?? "Unassigned"}
        {book.author ? ` · ${book.author}` : ""}
        {book.edition ? ` · ${book.edition}` : ""}
        {book.pageCount ? ` · ${book.pageCount} pages` : ""}
      </p>

      {book.extractionNote ? <Card className="mb-4 p-4 text-sm text-muted">{book.extractionNote}</Card> : null}

      <div className="mb-4 flex flex-wrap gap-2">
        <Link to="/read/$bookId" params={{ bookId }}>
          <Button>Open reader</Button>
        </Link>
        <Button variant="outline" onClick={() => addChapter(bookId, chapters)}>
          Add chapter
        </Button>
        <Button
          variant="ghost"
          onClick={async () => {
            if (!confirm("Delete this book and its local file?")) return;
            await deleteBook(bookId);
            toast.success("Book removed from this device.");
            navigate({ to: "/library" });
          }}
        >
          Delete
        </Button>
      </div>

      <ul className="space-y-3">
        {chapters.map((ch) => {
          const chTopics = topics.filter((t) => t.chapterId === ch.id);
          return (
            <Card key={ch.id} className="p-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-medium">{ch.title}</p>
                  <p className="text-xs text-muted">
                    pp. {ch.pageStart}–{ch.pageEnd}
                  </p>
                </div>
                <StatusChip status={ch.status} />
              </div>
              <div className="mt-3 space-y-2">
                {chTopics.map((t) => (
                  <div key={t.id} className="rounded-xl bg-surface-2 p-3">
                    <div className="mb-1.5 flex items-center justify-between gap-2">
                      <p className="text-sm font-medium">{t.title}</p>
                      <StatusChip status={t.status} />
                    </div>
                    <KnowledgeBar score={knowledge[t.id] ?? 0} />
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      <Button size="sm" variant="ghost" onClick={() => setTopicStatus(t.id, "reading")}>
                        Reading
                      </Button>
                      <Link to="/read/$bookId" params={{ bookId }} search={{ page: t.pageStart ?? ch.pageStart }}>
                        <Button size="sm" variant="ghost">
                          Open
                        </Button>
                      </Link>
                      <Link to="/practice/run" search={{ mode: "topic", topicId: t.id }}>
                        <Button size="sm" variant="ghost">
                          Practice
                        </Button>
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
              <Button size="sm" variant="outline" className="mt-3" onClick={() => setAiOpen(ch.id)}>
                Generate questions
              </Button>
            </Card>
          );
        })}
      </ul>

      <Dialog open={!!aiOpen} onOpenChange={(o) => !o && setAiOpen(null)}>
        <DialogContent title="Generate questions">
          {aiOpen ? (
            <GenerateForm
              bookId={bookId}
              bookName={book.name}
              chapter={chapters.find((c) => c.id === aiOpen)!}
              examId={book.examId}
              onDone={() => setAiOpen(null)}
            />
          ) : null}
        </DialogContent>
      </Dialog>
    </Screen>
  );
}

async function addChapter(bookId: string, existing: Chapter[]) {
  const title = prompt("Chapter title");
  if (!title?.trim()) return;
  const start = Number(prompt("Start page", "1") ?? "1");
  const end = Number(prompt("End page", String(start)) ?? start);
  const ch: Chapter = {
    id: nid(),
    bookId,
    title: title.trim(),
    pageStart: start || 1,
    pageEnd: end || start || 1,
    order: existing.length,
    status: "not_started",
  };
  await saveChapters(bookId, [...existing, ch]);
}

function GenerateForm({
  bookId,
  bookName,
  chapter,
  examId,
  onDone,
}: {
  bookId: string;
  bookName: string;
  chapter: Chapter;
  examId: string | null;
  onDone: () => void;
}) {
  const [diff, setDiff] = useState<Difficulty | "mixed">("mixed");
  const [busy, setBusy] = useState(false);
  const [drafts, setDrafts] = useState<Question[]>([]);

  const run = async () => {
    setBusy(true);
    try {
      const db = requireDb();
      const pages = await db.pageTexts.where("bookId").equals(bookId).toArray();
      const text = pages
        .filter((p) => p.page >= chapter.pageStart && p.page <= chapter.pageEnd)
        .map((p) => p.text)
        .join("\n");
      const res = await generateChapterQuestions({
        data: { chapterTitle: chapter.title, bookName, difficulty: diff, text },
      });
      if (!res.ok) {
        toast.error(res.error);
        return;
      }
      const parsed = JSON.parse(res.text.replace(/```json|```/g, "").trim()) as {
        questions?: {
          type: Question["type"];
          stem: string;
          options?: { id: string; text: string }[];
          correctAnswer: string;
          explanation: string;
          difficulty: Difficulty;
        }[];
      };
      const list: Question[] = (parsed.questions ?? []).map((raw) => ({
        id: nid(),
        type: raw.type ?? "mcq",
        stem: raw.stem,
        options: raw.options ?? [],
        correctAnswer: raw.correctAnswer,
        explanation: raw.explanation,
        examId,
        subjectId: null,
        chapterId: chapter.id,
        topicId: null,
        bookId,
        page: chapter.pageStart,
        difficulty: raw.difficulty ?? "medium",
        source: "ai",
        tags: ["ai"],
        createdAt: Date.now(),
      }));
      if (!list.length) {
        toast.error("No questions were returned. Nothing was added to the bank.");
        return;
      }
      setDrafts(list);
    } catch {
      toast.error("Could not parse generated questions. Nothing was saved.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-3">
      <p className="text-xs text-muted">
        Generated by AI from extracted chapter text. Review before they enter the question bank.
      </p>
      <Field label="Difficulty">
        <NativeSelect value={diff} onChange={(e) => setDiff(e.target.value as Difficulty | "mixed")}>
          <option value="easy">Easy</option>
          <option value="medium">Medium</option>
          <option value="hard">Hard</option>
          <option value="mixed">Mixed</option>
        </NativeSelect>
      </Field>
      <Button className="w-full" disabled={busy} onClick={run}>
        {busy ? "Generating…" : "Generate from this chapter"}
      </Button>
      {drafts.map((d) => (
        <Card key={d.id} className="p-3">
          <p className="text-sm">{d.stem}</p>
          <p className="mt-1 text-[11px] text-subtle">Answer: {d.correctAnswer}</p>
        </Card>
      ))}
      {drafts.length ? (
        <Button
          className="w-full"
          onClick={async () => {
            for (const d of drafts) {
              const { id: _id, createdAt: _c, ...rest } = d;
              await createQuestion(rest);
            }
            toast.success(`${drafts.length} saved.`);
            onDone();
          }}
        >
          Save to question bank
        </Button>
      ) : null}
    </div>
  );
}
