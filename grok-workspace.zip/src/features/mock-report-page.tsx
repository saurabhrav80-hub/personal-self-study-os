import { Link } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { EmptyState, Screen, SectionLabel } from "@/components/ui/empty";
import { analyzeMock, whyLosingMarks } from "@/lib/study/engines";
import { MISTAKE_LABEL } from "@/lib/study/types";
import { useMistakes, useMockResults, useMocks, useQuestions } from "@/lib/study/hooks";

export function MockReportPage({ resultId }: { resultId: string }) {
  const results = useMockResults();
  const mocks = useMocks();
  const questions = useQuestions();
  const mistakes = useMistakes();
  const result = results.find((r) => r.id === resultId);
  const mock = mocks.find((m) => m.id === result?.mockId);

  if (!result || !mock) {
    return (
      <Screen title="Report">
        <EmptyState title="Report not found" body="This result is not on this device." />
      </Screen>
    );
  }

  const qset = questions.filter((q) => mock.questionIds.includes(q.id));
  const relatedMistakes = mistakes.filter((m) => result.answers.some((a) => a.questionId === m.questionId && m.createdAt >= result.startedAt && m.createdAt <= result.submittedAt + 5000));
  const insight = analyzeMock({
    result,
    questions: qset,
    mistakes: relatedMistakes,
    timeLimitMin: mock.timeLimitMin,
    sections: mock.sections.length ? mock.sections : [{ name: "Paper", questionIds: mock.questionIds }],
  });
  const cats = whyLosingMarks(relatedMistakes);

  const byDiff = { easy: { c: 0, n: 0 }, medium: { c: 0, n: 0 }, hard: { c: 0, n: 0 } };
  for (const a of result.answers) {
    const q = qset.find((x) => x.id === a.questionId);
    if (!q || a.skipped) continue;
    const ok = a.answer === q.correctAnswer;
    byDiff[q.difficulty].n += 1;
    if (ok) byDiff[q.difficulty].c += 1;
  }

  return (
    <Screen title={mock.name}>
      <p className="mb-4 text-sm text-muted">
        Submitted {new Date(result.submittedAt).toLocaleString()}
      </p>
      <div className="mb-6 grid grid-cols-2 gap-2">
        <Metric label="Score" value={`${result.score.toFixed(1)}/${result.maxScore}`} />
        <Metric label="Accuracy" value={`${Math.round(result.accuracy)}%`} />
        <Metric label="Attempt rate" value={`${Math.round(result.attemptRate)}%`} />
        <Metric label="Time used" value={`${Math.round(result.timeEfficiency)}%`} />
      </div>

      {mock.sections.length ? (
        <>
          <SectionLabel>Sections</SectionLabel>
          <ul className="mb-5 space-y-2">
            {mock.sections.map((s) => {
              const rows = result.answers.filter((a) => s.questionIds.includes(a.questionId) && a.answer);
              const correct = rows.filter((a) => {
                const q = qset.find((x) => x.id === a.questionId);
                return q && a.answer === q.correctAnswer;
              }).length;
              const acc = rows.length ? (correct / rows.length) * 100 : 0;
              return (
                <li key={s.name}>
                  <Card className="flex items-center justify-between p-3">
                    <span>{s.name}</span>
                    <span className="tabular text-sm">{Math.round(acc)}% · {rows.length} att.</span>
                  </Card>
                </li>
              );
            })}
          </ul>
        </>
      ) : null}

      <SectionLabel>Difficulty</SectionLabel>
      <div className="mb-5 grid grid-cols-3 gap-2 text-center text-sm">
        {(["easy", "medium", "hard"] as const).map((d) => (
          <Card key={d} className="p-3">
            <p className="capitalize text-muted">{d}</p>
            <p className="tabular font-display text-lg">
              {byDiff[d].n ? `${Math.round((byDiff[d].c / byDiff[d].n) * 100)}%` : "—"}
            </p>
          </Card>
        ))}
      </div>

      {cats.length ? (
        <>
          <SectionLabel>Why marks leaked</SectionLabel>
          <ul className="mb-5 space-y-1">
            {cats.map((c) => (
              <li key={c.category} className="flex justify-between text-sm">
                <span>{MISTAKE_LABEL[c.category as keyof typeof MISTAKE_LABEL] ?? c.category}</span>
                <span className="tabular">{c.count}</span>
              </li>
            ))}
          </ul>
        </>
      ) : null}

      <SectionLabel>What went wrong</SectionLabel>
      <List items={insight.wentWrong} empty="No negative pattern was strong enough to call from this sitting." />
      <SectionLabel>What went well</SectionLabel>
      <List items={insight.wentWell} empty="Not enough positive signal to highlight yet." />
      <SectionLabel>Fix next</SectionLabel>
      <List items={insight.fixNext} empty="Sit another mock after more topic practice." />

      <Link to="/mocks" className="mt-4 inline-block text-sm text-muted">
        Back to mocks
      </Link>
    </Screen>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <Card className="p-3">
      <p className="text-xs text-muted">{label}</p>
      <p className="font-display text-2xl tabular">{value}</p>
    </Card>
  );
}

function List({ items, empty }: { items: string[]; empty: string }) {
  if (!items.length) return <p className="mb-5 text-sm text-muted">{empty}</p>;
  return (
    <ul className="mb-5 space-y-2">
      {items.map((t) => (
        <li key={t} className="rounded-2xl bg-surface px-4 py-3 text-sm shadow-[var(--shadow-border)]">
          {t}
        </li>
      ))}
    </ul>
  );
}
