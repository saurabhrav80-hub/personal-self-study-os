import { Link, useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { EmptyState, Screen } from "@/components/ui/empty";
import { useNotes } from "@/lib/study/hooks";
import { saveNote } from "@/lib/study/repo";

export function NotesListPage() {
  const notes = useNotes();
  const navigate = useNavigate();
  return (
    <Screen
      title="Notes"
      action={
        <Button
          size="sm"
          onClick={async () => {
            const n = await saveNote({ title: "Untitled", body: "", type: "text" });
            navigate({ to: "/notes/$noteId", params: { noteId: n.id } });
          }}
        >
          New
        </Button>
      }
    >
      {notes.length === 0 ? (
        <EmptyState title="No notes yet" body="Capture concept, question, book, or revision notes. Everything is searchable." />
      ) : (
        <ul className="space-y-2">
          {notes.map((n) => (
            <li key={n.id}>
              <Link
                to="/notes/$noteId"
                params={{ noteId: n.id }}
                className="block rounded-2xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]"
              >
                <p className="text-[11px] text-subtle uppercase">{n.type}</p>
                <p className="font-medium">{n.title || "Untitled"}</p>
                <p className="line-clamp-2 text-xs text-muted">{n.body}</p>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </Screen>
  );
}
