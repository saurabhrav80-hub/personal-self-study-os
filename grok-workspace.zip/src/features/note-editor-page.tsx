import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Input, NativeSelect, Textarea } from "@/components/ui/input";
import { Screen } from "@/components/ui/empty";
import { useExams, useNotes } from "@/lib/study/hooks";
import { deleteNote, saveNote } from "@/lib/study/repo";
import type { NoteType } from "@/lib/study/types";

export function NoteEditorPage({ noteId }: { noteId: string }) {
  const notes = useNotes();
  const exams = useExams();
  const note = notes.find((n) => n.id === noteId);
  const [title, setTitle] = useState(note?.title ?? "");
  const [body, setBody] = useState(note?.body ?? "");
  const [type, setType] = useState<NoteType>(note?.type ?? "text");
  const [examId, setExamId] = useState(note?.examId ?? "");
  const navigate = useNavigate();

  useEffect(() => {
    if (note) {
      setTitle(note.title);
      setBody(note.body);
      setType(note.type);
      setExamId(note.examId ?? "");
    }
  }, [note?.id]);

  if (!note) {
    return (
      <Screen title="Note">
        <p className="text-muted">Note not found.</p>
      </Screen>
    );
  }

  return (
    <Screen title="Edit note">
      <div className="space-y-3">
        <NativeSelect value={type} onChange={(e) => setType(e.target.value as NoteType)}>
          {["text", "concept", "question", "mistake", "book", "revision"].map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </NativeSelect>
        <NativeSelect value={examId} onChange={(e) => setExamId(e.target.value)}>
          <option value="">No exam</option>
          {exams.map((e) => (
            <option key={e.id} value={e.id}>
              {e.name}
            </option>
          ))}
        </NativeSelect>
        <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Title" />
        <Textarea className="min-h-48" value={body} onChange={(e) => setBody(e.target.value)} placeholder="Body" />
        <Button
          className="w-full"
          onClick={async () => {
            await saveNote({ id: note.id, title, body, type, examId: examId || null });
            navigate({ to: "/notes" });
          }}
        >
          Save
        </Button>
        <Button
          variant="ghost"
          className="w-full"
          onClick={async () => {
            await deleteNote(note.id);
            navigate({ to: "/notes" });
          }}
        >
          Delete
        </Button>
      </div>
    </Screen>
  );
}
