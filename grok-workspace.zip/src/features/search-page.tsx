import { useEffect, useState } from "react";
import { AppLink } from "@/components/app-link";
import { EmptyState, Screen } from "@/components/ui/empty";
import { Input } from "@/components/ui/input";
import { globalSearch } from "@/lib/study/search";
import type { SearchHit } from "@/lib/study/types";

export function SearchPage() {
  const [q, setQ] = useState("");
  const [hits, setHits] = useState<SearchHit[]>([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const t = setTimeout(async () => {
      if (q.trim().length < 2) {
        setHits([]);
        return;
      }
      setBusy(true);
      try {
        setHits(await globalSearch(q));
      } finally {
        setBusy(false);
      }
    }, 180);
    return () => clearTimeout(t);
  }, [q]);

  return (
    <Screen title="Search">
      <Input
        autoFocus
        placeholder="Working capital, duration, inventory…"
        value={q}
        onChange={(e) => setQ(e.target.value)}
      />
      <p className="mt-2 text-xs text-subtle">
        {busy ? "Searching locally…" : "Books, questions, notes, formulas, mistakes, pages"}
      </p>
      {q.trim().length >= 2 && !busy && hits.length === 0 ? (
        <EmptyState className="mt-6" title="No matches" body="Nothing in your local library matched that phrase." />
      ) : (
        <ul className="mt-4 space-y-2">
          {hits.map((h) => (
            <li key={h.id}>
              <AppLink href={h.href} className="block rounded-2xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]">
                <p className="text-[11px] tracking-wide text-subtle uppercase">{h.kind}</p>
                <p className="font-medium">{h.title}</p>
                {h.snippet ? <p className="mt-1 line-clamp-2 text-xs text-muted">{h.snippet}</p> : null}
              </AppLink>
            </li>
          ))}
        </ul>
      )}
    </Screen>
  );
}
