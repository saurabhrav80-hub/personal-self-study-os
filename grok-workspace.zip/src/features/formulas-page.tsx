import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { EmptyState, Screen } from "@/components/ui/empty";
import { Field, Input, NativeSelect, Textarea } from "@/components/ui/input";
import { useExams, useFormulas } from "@/lib/study/hooks";
import { addRevision, createFormula } from "@/lib/study/repo";

const CATS = ["All", "CFA", "CAT", "GRE", "Finance", "Statistics", "Economics", "Mathematics"];

export function FormulasPage() {
  const formulas = useFormulas();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("All");
  const shown = useMemo(() => {
    return formulas.filter((f) => {
      const hay = `${f.name} ${f.formula} ${f.meaning} ${f.category}`.toLowerCase();
      if (q && !hay.includes(q.toLowerCase())) return false;
      if (cat === "All") return true;
      if (cat === "CFA") return f.examIds.includes("exam-cfa") || f.category === "Finance";
      if (cat === "CAT") return f.examIds.includes("exam-cat");
      if (cat === "GRE") return f.examIds.includes("exam-gre");
      return f.category === cat;
    });
  }, [formulas, q, cat]);

  return (
    <Screen
      title="Formula vault"
      action={
        <AddFormulaButton />
      }
    >
      <Input placeholder="Search formulas" value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="mt-3 mb-4 flex gap-1 overflow-x-auto pb-1">
        {CATS.map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => setCat(c)}
            className={`h-9 shrink-0 rounded-full px-3 text-sm ${cat === c ? "bg-ink text-paper" : "bg-surface shadow-[var(--shadow-border)]"}`}
          >
            {c}
          </button>
        ))}
      </div>
      {shown.length === 0 ? (
        <EmptyState title="No formulas" body="Add your own. Starter formulas can be kept or ignored." />
      ) : (
        <ul className="space-y-2">
          {shown.map((f) => (
            <li key={f.id}>
              <Card className="p-4">
                <p className="text-xs text-subtle">{f.category}</p>
                <p className="font-display text-lg">{f.name}</p>
                <p className="mt-1 font-mono text-sm">{f.formula}</p>
                <p className="mt-2 text-sm text-muted">{f.meaning}</p>
                {f.whenToUse ? <p className="mt-2 text-xs text-muted">When: {f.whenToUse}</p> : null}
                {f.commonMistake ? <p className="mt-1 text-xs text-bad">Trap: {f.commonMistake}</p> : null}
                {f.example ? <p className="mt-1 text-xs text-muted">e.g. {f.example}</p> : null}
                <Button
                  size="sm"
                  variant="ghost"
                  className="mt-2"
                  onClick={async () => {
                    await addRevision({
                      kind: "formula",
                      refId: f.id,
                      prompt: `Recall the formula for ${f.name}`,
                      answer: `${f.formula}\n${f.meaning}`,
                      examId: f.examIds[0] ?? null,
                    });
                    toast.success("Added to revision.");
                  }}
                >
                  Add to revision
                </Button>
              </Card>
            </li>
          ))}
        </ul>
      )}
    </Screen>
  );
}

function AddFormulaButton() {
  const [open, setOpen] = useState(false);
  const exams = useExams();
  const [name, setName] = useState("");
  const [formula, setFormula] = useState("");
  const [meaning, setMeaning] = useState("");
  const [category, setCategory] = useState("Mathematics");
  const [examId, setExamId] = useState("");
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm">Add</Button>
      </DialogTrigger>
      <DialogContent title="New formula">
        <div className="space-y-3">
          <Field label="Name">
            <Input value={name} onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="Formula">
            <Input value={formula} onChange={(e) => setFormula(e.target.value)} />
          </Field>
          <Field label="Meaning">
            <Textarea value={meaning} onChange={(e) => setMeaning(e.target.value)} />
          </Field>
          <Field label="Category">
            <NativeSelect value={category} onChange={(e) => setCategory(e.target.value)}>
              {CATS.filter((c) => c !== "All" && !["CFA", "CAT", "GRE"].includes(c)).map((c) => (
                <option key={c}>{c}</option>
              ))}
            </NativeSelect>
          </Field>
          <Field label="Exam">
            <NativeSelect value={examId} onChange={(e) => setExamId(e.target.value)}>
              <option value="">None</option>
              {exams.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.name}
                </option>
              ))}
            </NativeSelect>
          </Field>
          <Button
            className="w-full"
            onClick={async () => {
              if (!name.trim() || !formula.trim()) return;
              await createFormula({
                name: name.trim(),
                formula: formula.trim(),
                meaning,
                variables: [],
                example: "",
                whenToUse: "",
                commonMistake: "",
                examIds: examId ? [examId] : [],
                category,
                relatedConceptIds: [],
              });
              setOpen(false);
              setName("");
              setFormula("");
              setMeaning("");
            }}
          >
            Save
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
