import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Field, Input, NativeSelect, Textarea } from "@/components/ui/input";
import { Screen } from "@/components/ui/empty";
import { useExams, useTopics } from "@/lib/study/hooks";
import { createQuestion } from "@/lib/study/repo";
import type { Difficulty, QuestionType } from "@/lib/study/types";

export function QuestionNewPage() {
  const exams = useExams();
  const topics = useTopics();
  const navigate = useNavigate();
  const [type, setType] = useState<QuestionType>("mcq");
  const [stem, setStem] = useState("");
  const [a, setA] = useState("");
  const [b, setB] = useState("");
  const [c, setC] = useState("");
  const [d, setD] = useState("");
  const [correct, setCorrect] = useState("a");
  const [explanation, setExplanation] = useState("");
  const [examId, setExamId] = useState(exams[0]?.id ?? "");
  const [topicId, setTopicId] = useState("");
  const [difficulty, setDifficulty] = useState<Difficulty>("medium");
  const [numerical, setNumerical] = useState("");

  const save = async () => {
    if (!stem.trim()) {
      toast.error("Question text is required.");
      return;
    }
    const options =
      type === "mcq"
        ? [
            { id: "a", text: a },
            { id: "b", text: b },
            { id: "c", text: c },
            { id: "d", text: d },
          ]
        : type === "tf"
          ? [
              { id: "true", text: "True" },
              { id: "false", text: "False" },
            ]
          : [];
    await createQuestion({
      type,
      stem: stem.trim(),
      options,
      correctAnswer: type === "mcq" || type === "tf" ? correct : numerical.trim(),
      explanation,
      examId: examId || null,
      subjectId: null,
      chapterId: null,
      topicId: topicId || null,
      bookId: null,
      page: null,
      difficulty,
      source: "user",
      tags: [],
    });
    toast.success("Saved to the question bank.");
    navigate({ to: "/practice" });
  };

  return (
    <Screen title="New question">
      <div className="space-y-3">
        <Field label="Type">
          <NativeSelect value={type} onChange={(e) => setType(e.target.value as QuestionType)}>
            <option value="mcq">MCQ</option>
            <option value="numerical">Numerical</option>
            <option value="tf">True / False</option>
            <option value="short">Short answer</option>
            <option value="custom">Custom</option>
          </NativeSelect>
        </Field>
        <Field label="Stem">
          <Textarea value={stem} onChange={(e) => setStem(e.target.value)} />
        </Field>
        {type === "mcq" ? (
          <>
            <Field label="A">
              <Input value={a} onChange={(e) => setA(e.target.value)} />
            </Field>
            <Field label="B">
              <Input value={b} onChange={(e) => setB(e.target.value)} />
            </Field>
            <Field label="C">
              <Input value={c} onChange={(e) => setC(e.target.value)} />
            </Field>
            <Field label="D">
              <Input value={d} onChange={(e) => setD(e.target.value)} />
            </Field>
            <Field label="Correct">
              <NativeSelect value={correct} onChange={(e) => setCorrect(e.target.value)}>
                <option value="a">A</option>
                <option value="b">B</option>
                <option value="c">C</option>
                <option value="d">D</option>
              </NativeSelect>
            </Field>
          </>
        ) : type === "tf" ? (
          <Field label="Correct">
            <NativeSelect value={correct} onChange={(e) => setCorrect(e.target.value)}>
              <option value="true">True</option>
              <option value="false">False</option>
            </NativeSelect>
          </Field>
        ) : (
          <Field label="Correct answer">
            <Input value={numerical} onChange={(e) => setNumerical(e.target.value)} />
          </Field>
        )}
        <Field label="Explanation">
          <Textarea value={explanation} onChange={(e) => setExplanation(e.target.value)} />
        </Field>
        <Field label="Exam">
          <NativeSelect value={examId} onChange={(e) => setExamId(e.target.value)}>
            <option value="">None</option>
            {exams.map((e) => (
              <option key={e.id} value={e.id}>
                {e.name}
              </option>
            ))}
          </NativeSelect>
        </Field>
        <Field label="Topic">
          <NativeSelect value={topicId} onChange={(e) => setTopicId(e.target.value)}>
            <option value="">None</option>
            {topics
              .filter((t) => !examId || t.examId === examId)
              .map((t) => (
                <option key={t.id} value={t.id}>
                  {t.title}
                </option>
              ))}
          </NativeSelect>
        </Field>
        <Field label="Difficulty">
          <NativeSelect value={difficulty} onChange={(e) => setDifficulty(e.target.value as Difficulty)}>
            <option value="easy">Easy</option>
            <option value="medium">Medium</option>
            <option value="hard">Hard</option>
          </NativeSelect>
        </Field>
        <Button className="w-full" onClick={save}>
          Save to bank
        </Button>
      </div>
    </Screen>
  );
}
