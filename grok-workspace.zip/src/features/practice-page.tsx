import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { EmptyState, Screen, SectionLabel } from "@/components/ui/empty";
import { PATTERN_COPY, topicAnalytics } from "@/lib/study/engines";
import { useAttempts, useExams, useMistakes, useQuestions, useSettingsLive, useTopics } from "@/lib/study/hooks";

export function PracticePage() {
  const exams = useExams();
  const questions = useQuestions();
  const attempts = useAttempts();
  const topics = useTopics();
  const mistakes = useMistakes();
  const settings = useSettingsLive();
  const analytics = topicAnalytics(topics, questions, attempts, settings?.targetTimes ?? {});

  return (
    <Screen
      title="Practice"
      action={
        <Link to="/questions/new">
          <Button size="sm" variant="outline">
            Add question
          </Button>
        </Link>
      }
    >
      <SectionLabel>Modes</SectionLabel>
      <div className="mb-6 grid grid-cols-2 gap-2">
        <Mode search={{ mode: "exam" }} label="By exam" />
        <Mode search={{ mode: "topic" }} label="By topic" />
        <Mode search={{ mode: "difficulty" }} label="By difficulty" />
        <Mode search={{ mode: "weak" }} label="Weak areas" />
        <Mode search={{ mode: "random" }} label="Random" />
        <Mode search={{ mode: "timed", timed: "1" }} label="Timed" />
        <Mode search={{ mode: "custom" }} label="Custom set" />
        <Link
          to="/mocks"
          className="flex min-h-14 items-center justify-center rounded-2xl bg-surface px-3 text-center text-sm font-medium shadow-[var(--shadow-border)]"
        >
          Mocks
        </Link>
      </div>

      <div className="mb-6 grid grid-cols-3 gap-2 text-center">
        <Stat n={questions.length} l="Questions" />
        <Stat n={attempts.length} l="Attempts" />
        <Stat n={mistakes.length} l="Mistakes" />
      </div>

      {questions.length === 0 ? (
        <EmptyState
          title="Question bank is empty"
          body="Add questions manually, keep the starter set, or generate from a chapter after uploading a book."
          action={
            <Link to="/questions/new">
              <Button>Create a question</Button>
            </Link>
          }
        />
      ) : null}

      <SectionLabel>Topic analyzer</SectionLabel>
      {analytics.length === 0 ? (
        <p className="mb-6 text-sm text-muted">Practice a few items to see accuracy, speed, and patterns.</p>
      ) : (
        <ul className="mb-6 space-y-2">
          {analytics.slice(0, 8).map((a) => (
            <li key={a.topicId}>
              <Link to="/practice/run" search={{ mode: "topic", topicId: a.topicId }}>
                <Card className="p-3">
                  <div className="flex items-baseline justify-between gap-2">
                    <p className="font-medium">{a.title}</p>
                    <p className="tabular text-sm">{a.accuracy.toFixed(0)}%</p>
                  </div>
                  <p className="mt-1 text-xs text-muted">
                    {a.questions} attempts · avg {Math.round(a.avgTimeMs / 1000)}s · {PATTERN_COPY[a.pattern]}
                  </p>
                </Card>
              </Link>
            </li>
          ))}
        </ul>
      )}

      <div className="grid grid-cols-2 gap-2">
        <Link to="/mistakes" className="rounded-xl bg-surface p-4 text-sm font-medium shadow-[var(--shadow-border)]">
          Mistake intelligence
        </Link>
        <Link to="/insights" className="rounded-xl bg-surface p-4 text-sm font-medium shadow-[var(--shadow-border)]">
          Speed lab
        </Link>
      </div>

      <SectionLabel>Bank by exam</SectionLabel>
      <ul className="space-y-2">
        {exams.map((e) => {
          const n = questions.filter((q) => q.examId === e.id).length;
          return (
            <li key={e.id}>
              <Link to="/practice/run" search={{ mode: "exam", examId: e.id }}>
                <Card className="flex items-center justify-between p-4">
                  <span className="font-medium">{e.name}</span>
                  <span className="text-sm text-muted">{n} questions</span>
                </Card>
              </Link>
            </li>
          );
        })}
      </ul>
    </Screen>
  );
}

function Mode({ search, label }: { search: { mode: string; timed?: string }; label: string }) {
  return (
    <Link
      to="/practice/run"
      search={search}
      className="flex min-h-14 items-center justify-center rounded-2xl bg-surface px-3 text-center text-sm font-medium shadow-[var(--shadow-border)]"
    >
      {label}
    </Link>
  );
}

function Stat({ n, l }: { n: number; l: string }) {
  return (
    <div className="rounded-2xl bg-surface py-3 shadow-[var(--shadow-border)]">
      <p className="font-display text-2xl tabular">{n}</p>
      <p className="text-[11px] text-subtle">{l}</p>
    </div>
  );
}
