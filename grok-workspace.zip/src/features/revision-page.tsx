import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { EmptyState, Screen, SectionLabel } from "@/components/ui/empty";
import { Textarea } from "@/components/ui/input";
import { revisionBucket } from "@/lib/study/engines";
import { useRevisions } from "@/lib/study/hooks";
import { addRevision, reviewRevision } from "@/lib/study/repo";
import type { RecallResult, RevisionItem } from "@/lib/study/types";

export function RevisionPage() {
  const items = useRevisions();
  const [active, setActive] = useState<RevisionItem | null>(null);
  const [draft, setDraft] = useState("");
  const [revealed, setRevealed] = useState(false);
  const now = Date.now();

  const groups = useMemo(() => {
    const today: RevisionItem[] = [];
    const soon: RevisionItem[] = [];
    const later: RevisionItem[] = [];
    for (const i of items) {
      const b = revisionBucket(i.dueAt, now);
      if (b === "today") today.push(i);
      else if (b === "soon") soon.push(i);
      else later.push(i);
    }
    today.sort((a, b) => a.dueAt - b.dueAt);
    return { today, soon, later };
  }, [items, now]);

  const rate = async (r: RecallResult) => {
    if (!active) return;
    await reviewRevision(active.id, r);
    setActive(null);
    setDraft("");
    setRevealed(false);
  };

  return (
    <Screen
      title="Revision"
      action={
        <Button
          size="sm"
          variant="outline"
          onClick={async () => {
            const prompt = window.prompt("What should you be able to recall?");
            if (!prompt?.trim()) return;
            const answer = window.prompt("Answer to reveal after recall") ?? "";
            await addRevision({
              kind: "note",
              refId: "manual",
              prompt: prompt.trim(),
              answer: answer.trim(),
            });
          }}
        >
          Add card
        </Button>
      }
    >
      <p className="mb-5 text-sm text-muted">
        Recall first. Do not reread notes until you have attempted an answer.
      </p>

      {active ? (
        <Card className="mb-6 p-4">
          <p className="text-[11px] tracking-wide text-subtle uppercase">Active recall</p>
          <p className="mt-2 font-display text-xl leading-snug">{active.prompt}</p>
          {!revealed ? (
            <>
              <Textarea
                className="mt-4"
                placeholder="Write what you remember"
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
              />
              <Button className="mt-3 w-full" onClick={() => setRevealed(true)}>
                Reveal
              </Button>
            </>
          ) : (
            <>
              <div className="mt-4 rounded-xl bg-surface-2 p-3 text-sm">{active.answer || "No stored answer."}</div>
              <div className="mt-3 grid grid-cols-3 gap-2">
                <Button variant="secondary" onClick={() => rate("knew")}>
                  I knew it
                </Button>
                <Button variant="secondary" onClick={() => rate("partial")}>
                  Partial
                </Button>
                <Button variant="outline" onClick={() => rate("forgot")}>
                  Forgot
                </Button>
              </div>
            </>
          )}
        </Card>
      ) : null}

      <Bucket title="Due today" color="bg-bad" items={groups.today} onPick={(i) => { setActive(i); setRevealed(false); setDraft(""); }} />
      <Bucket title="Soon" color="bg-warn" items={groups.soon} onPick={(i) => { setActive(i); setRevealed(false); setDraft(""); }} />
      <Bucket title="Later" color="bg-good" items={groups.later} onPick={(i) => { setActive(i); setRevealed(false); setDraft(""); }} />

      {items.length === 0 ? (
        <EmptyState
          title="Nothing scheduled"
          body="Mark a topic for revision from the reader, or add a recall card."
        />
      ) : null}
    </Screen>
  );
}

function Bucket({
  title,
  color,
  items,
  onPick,
}: {
  title: string;
  color: string;
  items: RevisionItem[];
  onPick: (i: RevisionItem) => void;
}) {
  return (
    <section className="mb-5">
      <SectionLabel>
        <span className={`mr-2 inline-block size-2 rounded-full ${color}`} />
        {title} · {items.length}
      </SectionLabel>
      {items.length === 0 ? (
        <p className="text-sm text-muted">None.</p>
      ) : (
        <ul className="space-y-1.5">
          {items.map((i) => (
            <li key={i.id}>
              <button
                type="button"
                onClick={() => onPick(i)}
                className="flex min-h-12 w-full items-center rounded-2xl bg-surface px-4 text-left text-sm shadow-[var(--shadow-border)]"
              >
                {i.prompt}
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
