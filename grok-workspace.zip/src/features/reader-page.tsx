import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Bookmark as BookmarkIcon, ChevronLeft, ChevronRight, Highlighter, StickyNote, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/input";
import { useBook, useBookmarks, useChapters, useHighlights, useTopics } from "@/lib/study/hooks";
import { loadBookBytes } from "@/lib/study/pdf";
import { addBookmark, addHighlight, addRevision, markTopicEvent, saveNote, updateBook } from "@/lib/study/repo";
import { cn } from "@/lib/utils";

export function ReaderPage({ bookId, initialPage }: { bookId: string; initialPage?: number }) {
  const book = useBook(bookId);
  const chapters = useChapters(bookId);
  const topics = useTopics({ bookId });
  const highlights = useHighlights(bookId);
  const bookmarks = useBookmarks(bookId);
  const navigate = useNavigate();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const bytesRef = useRef<ArrayBuffer | null>(null);
  const [page, setPage] = useState(initialPage || book?.lastPage || 1);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [note, setNote] = useState("");
  const [drawer, setDrawer] = useState(false);
  const [hlText, setHlText] = useState("");

  useEffect(() => {
    if (initialPage) setPage(initialPage);
  }, [initialPage]);

  const paint = useCallback(
    async (n: number) => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      setBusy(true);
      try {
        if (!bytesRef.current) {
          bytesRef.current = await loadBookBytes(bookId);
        }
        if (!bytesRef.current) {
          setError("Original file is missing from local storage.");
          return;
        }
        const { renderPageToCanvas } = await import("@/lib/study/pdf");
        const width = Math.min(window.innerWidth - 16, 720);
        const scale = Math.max(0.9, width / 520);
        await renderPageToCanvas(bytesRef.current, n, canvas, scale);
        setError(null);
      } catch (e) {
        setError(e instanceof Error ? e.message : "Could not render this page.");
      } finally {
        setBusy(false);
      }
    },
    [bookId],
  );

  useEffect(() => {
    void paint(page);
  }, [page, paint]);

  useEffect(() => {
    if (!book) return;
    const progress = book.pageCount ? page / book.pageCount : 0;
    void updateBook(bookId, {
      lastPage: page,
      lastOpenedAt: Date.now(),
      readingProgress: progress,
      completionStatus: progress >= 0.98 ? "complete" : "reading",
    });
  }, [page, bookId, book?.pageCount]);

  const chapter = chapters.find((c) => page >= c.pageStart && page <= c.pageEnd);
  const topic = topics.find((t) => t.chapterId === chapter?.id);

  const go = (n: number) => {
    if (!book) return;
    setPage(Math.min(book.pageCount || n, Math.max(1, n)));
  };

  if (!book) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-bg">
        <p className="text-muted">Book not found.</p>
      </div>
    );
  }

  return (
    <div className="flex min-h-dvh flex-col bg-bg">
      <header className="flex h-12 items-center justify-between gap-2 border-b border-border px-2">
        <button
          type="button"
          className="flex size-11 items-center justify-center"
          onClick={() => navigate({ to: "/library/$bookId", params: { bookId } })}
          aria-label="Close reader"
        >
          <X className="size-5" />
        </button>
        <div className="min-w-0 text-center">
          <p className="truncate text-sm font-medium">{book.name}</p>
          <p className="truncate text-[11px] text-muted">
            {chapter?.title ?? "Document"} · {page}/{book.pageCount || "?"}
          </p>
        </div>
        <button type="button" className="flex size-11 items-center justify-center text-sm" onClick={() => setDrawer(true)}>
          Ch
        </button>
      </header>

      <div className="flex flex-1 justify-center overflow-auto bg-surface-2 p-2">
        {error ? (
          <p className="m-6 max-w-sm text-center text-sm text-muted">{error}</p>
        ) : (
          <canvas ref={canvasRef} className={cn("max-w-full shadow-[var(--shadow-border)]", busy && "opacity-60")} />
        )}
      </div>

      <div className="border-t border-border bg-bg px-3 pt-2 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
        <div className="mx-auto flex max-w-lg items-center justify-between gap-2">
          <Button variant="ghost" size="icon" onClick={() => go(page - 1)} disabled={page <= 1} aria-label="Previous page">
            <ChevronLeft />
          </Button>
          <form
            className="flex items-center gap-1 text-sm"
            onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);
              go(Number(fd.get("p")));
            }}
          >
            <input
              name="p"
              key={page}
              defaultValue={page}
              className="h-10 w-14 rounded-md bg-surface-2 text-center tabular"
              inputMode="numeric"
            />
            <span className="text-subtle">/ {book.pageCount || "—"}</span>
          </form>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => go(page + 1)}
            disabled={book.pageCount ? page >= book.pageCount : false}
            aria-label="Next page"
          >
            <ChevronRight />
          </Button>
        </div>
        <div className="mx-auto mt-2 grid max-w-lg grid-cols-4 gap-1">
          <Button
            size="sm"
            variant="secondary"
            onClick={async () => {
              if (topic) await markTopicEvent(topic.id, "read");
              toast.success("Marked as studied.");
            }}
          >
            Studied
          </Button>
          <Button
            size="sm"
            variant="secondary"
            onClick={async () => {
              if (!topic) {
                toast.error("No topic on this page to schedule.");
                return;
              }
              await addRevision({
                kind: "topic",
                refId: topic.id,
                prompt: `Recall: ${topic.title}`,
                answer: `From ${book.name}, ${chapter?.title ?? ""}.`,
                examId: book.examId,
                topicId: topic.id,
              });
              toast.success("Added to revision.");
            }}
          >
            Revise
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={async () => {
              await addBookmark({ bookId, page, title: chapter?.title ?? `Page ${page}` });
              toast.success("Bookmark saved.");
            }}
          >
            <BookmarkIcon className="size-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={async () => {
              const text = window.getSelection()?.toString().trim() || hlText || prompt("Highlight text") || "";
              if (!text) return;
              await addHighlight({ bookId, page, text, color: "ink", note: "" });
              setHlText("");
              toast.success("Highlight stored locally.");
            }}
          >
            <Highlighter className="size-4" />
          </Button>
        </div>
        <form
          className="mx-auto mt-2 flex max-w-lg gap-2"
          onSubmit={async (e) => {
            e.preventDefault();
            if (!note.trim()) return;
            await saveNote({
              type: "book",
              title: `${book.name} p.${page}`,
              body: note.trim(),
              bookId,
              chapterId: chapter?.id ?? null,
              topicId: topic?.id ?? null,
              examId: book.examId,
            });
            setNote("");
            toast.success("Note saved.");
          }}
        >
          <Textarea
            className="min-h-11 h-11 py-2.5"
            placeholder="Page note"
            value={note}
            onChange={(e) => setNote(e.target.value)}
          />
          <Button type="submit" size="icon" variant="secondary" aria-label="Save note">
            <StickyNote className="size-4" />
          </Button>
        </form>
      </div>

      {drawer ? (
        <div className="fixed inset-0 z-50 bg-ink/40" onClick={() => setDrawer(false)}>
          <div
            className="absolute right-0 bottom-0 left-0 max-h-[70dvh] overflow-y-auto rounded-t-2xl bg-surface p-4"
            onClick={(e) => e.stopPropagation()}
          >
            <p className="mb-3 font-display text-lg">Chapters</p>
            <ul className="space-y-1">
              {chapters.map((c) => (
                <li key={c.id}>
                  <button
                    type="button"
                    className="flex min-h-11 w-full items-center justify-between rounded-xl px-3 text-left text-sm hover:bg-surface-2"
                    onClick={() => {
                      go(c.pageStart);
                      setDrawer(false);
                    }}
                  >
                    <span>{c.title}</span>
                    <span className="text-xs text-subtle">{c.pageStart}</span>
                  </button>
                </li>
              ))}
            </ul>
            {bookmarks.length ? (
              <>
                <p className="mt-4 mb-2 text-xs tracking-wide text-subtle uppercase">Bookmarks</p>
                {bookmarks.map((b) => (
                  <button
                    key={b.id}
                    type="button"
                    className="block min-h-10 w-full rounded-lg px-3 text-left text-sm"
                    onClick={() => {
                      go(b.page);
                      setDrawer(false);
                    }}
                  >
                    p.{b.page} · {b.title}
                  </button>
                ))}
              </>
            ) : null}
            {highlights.length ? (
              <>
                <p className="mt-4 mb-2 text-xs tracking-wide text-subtle uppercase">Highlights</p>
                {highlights.slice(0, 12).map((h) => (
                  <p key={h.id} className="px-3 py-1 text-xs text-muted">
                    p.{h.page} — {h.text.slice(0, 80)}
                  </p>
                ))}
              </>
            ) : null}
          </div>
        </div>
      ) : null}
    </div>
  );
}
