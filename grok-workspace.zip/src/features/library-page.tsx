import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { Plus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { EmptyState, Screen, SectionLabel } from "@/components/ui/empty";
import { Field, Input, NativeSelect } from "@/components/ui/input";
import { useBooks, useExams, useSubjects } from "@/lib/study/hooks";
import { ingestPdfFile } from "@/lib/study/pdf";
import { stripExt } from "@/lib/utils";

export function LibraryPage() {
  const books = useBooks();
  const exams = useExams();
  const [filter, setFilter] = useState<string>("all");
  const shown = books.filter((b) => {
    if (filter === "all") return true;
    if (filter === "other") return !b.examId || !exams.some((e) => e.id === b.examId);
    return b.examId === filter;
  });

  return (
    <Screen title="Library" action={<AddBookButton />}>
      <div className="mb-4 flex gap-1.5 overflow-x-auto pb-1">
        <FilterChip active={filter === "all"} onClick={() => setFilter("all")}>
          All
        </FilterChip>
        {exams.map((e) => (
          <FilterChip key={e.id} active={filter === e.id} onClick={() => setFilter(e.id)}>
            {e.name}
          </FilterChip>
        ))}
        <FilterChip active={filter === "other"} onClick={() => setFilter("other")}>
          Other
        </FilterChip>
      </div>

      {shown.length === 0 ? (
        <EmptyState
          title="Upload your first book"
          body="PDFs are stored on this device. Text is extracted locally. Nothing is sent anywhere unless you later use Ask My Books with AI."
          action={<AddBookButton />}
        />
      ) : (
        <ul className="space-y-2">
          {shown.map((b) => (
            <li key={b.id}>
              <Link to="/library/$bookId" params={{ bookId: b.id }}>
                <Card className="flex items-center justify-between gap-3 p-4">
                  <div className="min-w-0">
                    <p className="truncate font-medium">{b.name}</p>
                    <p className="mt-0.5 truncate text-xs text-muted">
                      {exams.find((e) => e.id === b.examId)?.name ?? "Unassigned"}
                      {b.author ? ` · ${b.author}` : ""}
                      {b.pageCount ? ` · ${b.pageCount} pages` : ""}
                    </p>
                    <p className="mt-2 text-[11px] text-subtle">
                      {Math.round(b.readingProgress * 100)}% read
                      {b.extractionStatus === "failed" || b.extractionStatus === "manual"
                        ? " · needs structure"
                        : ""}
                    </p>
                  </div>
                  <div className="h-10 w-10 shrink-0 rounded-full bg-surface-2 p-1">
                    <div
                      className="h-full rounded-full bg-ink"
                      style={{
                        background: `conic-gradient(var(--app-ink) ${b.readingProgress * 360}deg, var(--app-surface-2) 0)`,
                      }}
                    />
                  </div>
                </Card>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </Screen>
  );
}

function FilterChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`h-9 shrink-0 rounded-full px-3.5 text-sm font-medium ${
        active ? "bg-ink text-paper" : "bg-surface text-muted shadow-[var(--shadow-border)]"
      }`}
    >
      {children}
    </button>
  );
}

function AddBookButton() {
  const [open, setOpen] = useState(false);
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm">
          <Plus className="size-4" />
          Add book
        </Button>
      </DialogTrigger>
      <DialogContent title="Add book">
        <AddBookForm onDone={() => setOpen(false)} />
      </DialogContent>
    </Dialog>
  );
}

function AddBookForm({ onDone }: { onDone: () => void }) {
  const exams = useExams();
  const subjects = useSubjects();
  const [file, setFile] = useState<File | null>(null);
  const [name, setName] = useState("");
  const [examId, setExamId] = useState(exams[0]?.id ?? "");
  const [subjectId, setSubjectId] = useState("");
  const [author, setAuthor] = useState("");
  const [edition, setEdition] = useState("");
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState("");

  const filteredSubjects = subjects.filter((s) => s.examId === examId);

  const submit = async () => {
    if (!file) {
      toast.error("Choose a PDF.");
      return;
    }
    setBusy(true);
    try {
      await ingestPdfFile(
        file,
        {
          name: name || stripExt(file.name),
          examId: examId || null,
          subjectId: subjectId || null,
          author,
          edition,
        },
        (p) => setProgress(p.note),
      );
      toast.success("Book stored locally.");
      onDone();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Import failed.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-3">
      <Field label="PDF file">
        <input
          type="file"
          accept="application/pdf"
          className="block w-full text-sm"
          onChange={(e) => {
            const f = e.target.files?.[0] ?? null;
            setFile(f);
            if (f && !name) setName(stripExt(f.name));
          }}
        />
      </Field>
      <Field label="Title">
        <Input value={name} onChange={(e) => setName(e.target.value)} />
      </Field>
      <Field label="Exam">
        <NativeSelect value={examId} onChange={(e) => setExamId(e.target.value)}>
          <option value="">Unassigned</option>
          {exams.map((ex) => (
            <option key={ex.id} value={ex.id}>
              {ex.name}
            </option>
          ))}
        </NativeSelect>
      </Field>
      <Field label="Subject">
        <NativeSelect value={subjectId} onChange={(e) => setSubjectId(e.target.value)}>
          <option value="">None</option>
          {filteredSubjects.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </NativeSelect>
      </Field>
      <Field label="Author">
        <Input value={author} onChange={(e) => setAuthor(e.target.value)} />
      </Field>
      <Field label="Edition">
        <Input value={edition} onChange={(e) => setEdition(e.target.value)} />
      </Field>
      {progress ? <p className="text-xs text-muted">{progress}</p> : null}
      <Button className="w-full" disabled={busy} onClick={submit}>
        {busy ? "Processing…" : "Store book"}
      </Button>
      <p className="text-[11px] text-subtle">
        Original file is kept. Headings are detected when possible; missing structure is never invented.
      </p>
    </div>
  );
}
