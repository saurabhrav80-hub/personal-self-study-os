import { useMemo } from "react";
import { Link } from "@tanstack/react-router";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Scatter,
  ScatterChart,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Card } from "@/components/ui/card";
import { EmptyState, Screen, SectionLabel } from "@/components/ui/empty";
import { PATTERN_COPY, topicAnalytics, whyLosingMarks } from "@/lib/study/engines";
import { MISTAKE_LABEL } from "@/lib/study/types";
import {
  useAttempts,
  useKnowledgeMap,
  useMistakes,
  useMockResults,
  useQuestions,
  useSessions,
  useSettingsLive,
  useTopics,
} from "@/lib/study/hooks";
import { formatDuration, formatMinutes } from "@/lib/utils";

export function InsightsPage() {
  const attempts = useAttempts();
  const questions = useQuestions();
  const mistakes = useMistakes();
  const topics = useTopics();
  const sessions = useSessions();
  const mocks = useMockResults();
  const knowledge = useKnowledgeMap();
  const settings = useSettingsLive();
  const analytics = topicAnalytics(topics, questions, attempts, settings?.targetTimes ?? {});

  const hours = sessions.reduce((s, x) => {
    const end = x.endedAt ?? Date.now();
    return s + Math.max(0, end - x.startedAt) / 3600000;
  }, 0);

  const acc = attempts.length ? (attempts.filter((a) => a.correct).length / attempts.length) * 100 : null;
  const trend = useMemo(() => {
    const byDay = new Map<string, { n: number; c: number }>();
    for (const a of attempts) {
      const d = new Date(a.createdAt).toISOString().slice(0, 10);
      const row = byDay.get(d) ?? { n: 0, c: 0 };
      row.n += 1;
      if (a.correct) row.c += 1;
      byDay.set(d, row);
    }
    return [...byDay.entries()]
      .sort((a, b) => a[0].localeCompare(b[0]))
      .slice(-14)
      .map(([day, v]) => ({ day: day.slice(5), accuracy: Math.round((v.c / v.n) * 100) }));
  }, [attempts]);

  const scatter = attempts.slice(0, 80).map((a) => ({
    time: Math.round(a.timeMs / 1000),
    ok: a.correct ? 1 : 0,
  }));

  const cats = whyLosingMarks(mistakes);
  const weak = analytics.filter((a) => a.pattern === "major" || a.accuracy < 55);
  const strong = analytics.filter((a) => a.pattern === "strong" || (a.accuracy >= 85 && a.questions >= 4));
  const improved = topics
    .map((t) => ({ t, k: knowledge[t.id] ?? 0 }))
    .filter((x) => x.k >= 70)
    .sort((a, b) => b.k - a.k)
    .slice(0, 5);

  const atRisk = topics.filter((t) => {
    const k = knowledge[t.id] ?? 0;
    const stale = t.lastRevisedAt ? Date.now() - t.lastRevisedAt > 14 * 86400000 : t.status !== "not_started";
    return k > 20 && k < 55 && stale;
  });

  return (
    <Screen title="Insights" wide>
      <div className="mb-6 grid grid-cols-2 gap-2 sm:grid-cols-4">
        <Metric label="Study hours" value={hours ? formatMinutes(hours * 60) : "—"} />
        <Metric label="Questions" value={`${attempts.length}`} />
        <Metric label="Accuracy" value={acc == null ? "—" : `${Math.round(acc)}%`} />
        <Metric label="Mocks" value={`${mocks.length}`} />
      </div>

      <SectionLabel>Accuracy trend</SectionLabel>
      {trend.length < 2 ? (
        <p className="mb-6 text-sm text-muted">Not enough daily attempts to plot a trend.</p>
      ) : (
        <Card className="mb-6 h-48 p-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={trend}>
              <CartesianGrid stroke="var(--app-border)" vertical={false} />
              <XAxis dataKey="day" tick={{ fontSize: 11, fill: "var(--app-muted)" }} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: "var(--app-muted)" }} />
              <Tooltip />
              <Line type="monotone" dataKey="accuracy" stroke="var(--app-ink)" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      )}

      <SectionLabel>Speed lab · accuracy vs time</SectionLabel>
      {scatter.length < 4 ? (
        <p className="mb-6 text-sm text-muted">Timed attempts will appear here as a scatter of seconds vs correctness.</p>
      ) : (
        <Card className="mb-6 h-48 p-2">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart>
              <CartesianGrid stroke="var(--app-border)" />
              <XAxis dataKey="time" name="sec" tick={{ fontSize: 11, fill: "var(--app-muted)" }} />
              <YAxis dataKey="ok" ticks={[0, 1]} tick={{ fontSize: 11, fill: "var(--app-muted)" }} />
              <Tooltip />
              <Scatter data={scatter} fill="var(--app-ink)" />
            </ScatterChart>
          </ResponsiveContainer>
        </Card>
      )}

      <SectionLabel>Why am I losing marks?</SectionLabel>
      {cats.length === 0 ? (
        <EmptyState className="mb-6" title="No mistakes recorded" body="Incorrect answers can be classified after each question." />
      ) : (
        <ul className="mb-6 space-y-1">
          {cats.map((c) => (
            <li key={c.category} className="flex justify-between rounded-xl bg-surface px-4 py-2 text-sm">
              <span>{MISTAKE_LABEL[c.category as keyof typeof MISTAKE_LABEL] ?? c.category}</span>
              <span className="tabular">{c.count}</span>
            </li>
          ))}
        </ul>
      )}

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <SectionLabel>Weak / at risk</SectionLabel>
          {weak.length === 0 && atRisk.length === 0 ? (
            <p className="text-sm text-muted">No weak pattern yet.</p>
          ) : (
            <ul className="space-y-1 text-sm">
              {weak.slice(0, 6).map((w) => (
                <li key={w.topicId}>
                  <Link to="/practice/run" search={{ mode: "topic", topicId: w.topicId }}>
                    {w.title} · {Math.round(w.accuracy)}% · {PATTERN_COPY[w.pattern]}
                  </Link>
                </li>
              ))}
              {atRisk.slice(0, 4).map((t) => (
                <li key={t.id} className="text-muted">
                  {t.title} — knowledge {Math.round(knowledge[t.id] ?? 0)}%, revision stale
                </li>
              ))}
            </ul>
          )}
        </div>
        <div>
          <SectionLabel>Strong / improved</SectionLabel>
          {strong.length === 0 && improved.length === 0 ? (
            <p className="text-sm text-muted">Keep practicing to surface strengths.</p>
          ) : (
            <ul className="space-y-1 text-sm">
              {strong.slice(0, 6).map((w) => (
                <li key={w.topicId}>
                  {w.title} · {Math.round(w.accuracy)}% · avg {formatDuration(w.avgTimeMs)}
                </li>
              ))}
              {improved.map((x) => (
                <li key={x.t.id} className="text-muted">
                  {x.t.title} · knowledge {Math.round(x.k)}%
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <p className="mt-8 text-xs text-subtle">
        Target times are per exam in Settings. Patterns use your recorded times, not a universal clock.
      </p>
    </Screen>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <Card className="p-3">
      <p className="text-[11px] text-muted">{label}</p>
      <p className="font-display text-2xl tabular">{value}</p>
    </Card>
  );
}
