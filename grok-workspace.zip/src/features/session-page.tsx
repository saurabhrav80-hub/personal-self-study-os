import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Screen } from "@/components/ui/empty";
import { Field, Input, NativeSelect } from "@/components/ui/input";
import { useExams, useSessions, useTopics } from "@/lib/study/hooks";
import { endSession, startSession } from "@/lib/study/repo";
import { formatDuration } from "@/lib/utils";

export function SessionPage() {
  const exams = useExams();
  const topics = useTopics();
  const sessions = useSessions();
  const active = sessions.find((s) => !s.endedAt);
  const [examId, setExamId] = useState(exams[0]?.id ?? "");
  const [topicId, setTopicId] = useState("");
  const [minutes, setMinutes] = useState(45);
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  if (active) {
    const elapsed = now - active.startedAt;
    const planned = active.plannedMin * 60000;
    return (
      <Screen title="Study session">
        <p className="font-display text-4xl tabular">{formatDuration(elapsed)}</p>
        <p className="mt-1 text-sm text-muted">
          Planned {active.plannedMin} min · {active.title}
        </p>
        <p className="mt-4 text-sm">
          Questions {active.questionsSolved}
          {active.questionsSolved
            ? ` · ${Math.round((active.correctCount / active.questionsSolved) * 100)}% accuracy`
            : ""}
        </p>
        <div className="mt-6 flex flex-col gap-2">
          <Link
            to="/practice/run"
            search={{ mode: "topic", topicId: active.topicId ?? undefined, sessionId: active.id }}
          >
            <Button className="w-full">Practice in this session</Button>
          </Link>
          <Button variant="outline" onClick={() => endSession(active.id)}>
            End session
          </Button>
        </div>
        {elapsed > planned ? <p className="mt-4 text-xs text-warn">Past the planned duration.</p> : null}
      </Screen>
    );
  }

  const last = sessions[0];

  return (
    <Screen title="Start session">
      <div className="space-y-3">
        <Field label="Exam">
          <NativeSelect value={examId} onChange={(e) => setExamId(e.target.value)}>
            <option value="">None</option>
            {exams.map((e) => (
              <option key={e.id} value={e.id}>
                {e.name}
              </option>
            ))}
          </NativeSelect>
        </Field>
        <Field label="Topic">
          <NativeSelect value={topicId} onChange={(e) => setTopicId(e.target.value)}>
            <option value="">General</option>
            {topics
              .filter((t) => !examId || t.examId === examId)
              .map((t) => (
                <option key={t.id} value={t.id}>
                  {t.title}
                </option>
              ))}
          </NativeSelect>
        </Field>
        <Field label="Duration (minutes)">
          <Input type="number" value={minutes} onChange={(e) => setMinutes(Number(e.target.value))} />
        </Field>
        <Button
          className="w-full"
          size="lg"
          onClick={async () => {
            const topic = topics.find((t) => t.id === topicId);
            const exam = exams.find((e) => e.id === examId);
            await startSession({
              examId: examId || null,
              topicId: topicId || null,
              title: [exam?.name, topic?.title ?? "Study"].filter(Boolean).join(" — "),
              plannedMin: minutes || 25,
            });
          }}
        >
          Start
        </Button>
      </div>
      {last?.endedAt ? (
        <Card className="mt-8 p-4">
          <p className="text-xs text-subtle uppercase">Last session</p>
          <p className="mt-1 font-medium">{last.title}</p>
          <p className="text-sm text-muted">
            {formatDuration(last.endedAt - last.startedAt)} · {last.questionsSolved} questions
            {last.questionsSolved ? ` · ${Math.round((last.correctCount / last.questionsSolved) * 100)}%` : ""}
          </p>
        </Card>
      ) : null}
    </Screen>
  );
}
