import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { NativeSelect, Textarea } from "@/components/ui/input";
import { explainQuestion } from "@/lib/ai/study-ai";
import { MISTAKE_CATEGORIES, MISTAKE_LABEL, type Difficulty, type MistakeCategory, type Question } from "@/lib/study/types";
import { useExams, useMistakes, useQuestions, useTopics } from "@/lib/study/hooks";
import { classifyMistake, recordAttempt } from "@/lib/study/repo";
import { numericalMatch, shuffle } from "@/lib/utils";

export type PracticeSearch = {
  mode?: string;
  examId?: string;
  topicId?: string;
  difficulty?: Difficulty;
  timed?: string;
  count?: string;
  questionId?: string;
  sessionId?: string;
};

export function PracticeRunPage({ search }: { search: PracticeSearch }) {
  const all = useQuestions();
  const exams = useExams();
  const topics = useTopics();
  const mistakes = useMistakes();
  const navigate = useNavigate();
  const [setupDone, setSetupDone] = useState(!!search.questionId || search.mode === "random" || search.mode === "weak" || search.mode === "timed" || (!!search.examId && search.mode === "exam") || (!!search.topicId && search.mode === "topic"));
  const [examId, setExamId] = useState(search.examId ?? exams[0]?.id ?? "");
  const [topicId, setTopicId] = useState(search.topicId ?? "");
  const [difficulty, setDifficulty] = useState<Difficulty | "any">(search.difficulty ?? "any");
  const [count, setCount] = useState(Number(search.count ?? 8));
  const [timed, setTimed] = useState(search.timed === "1" || search.mode === "timed");
  const [queue, setQueue] = useState<Question[]>([]);
  const [idx, setIdx] = useState(0);
  const [answer, setAnswer] = useState("");
  const [confidence, setConfidence] = useState<number | null>(null);
  const [revealed, setRevealed] = useState(false);
  const [correct, setCorrect] = useState<boolean | null>(null);
  const [mistakeCat, setMistakeCat] = useState<MistakeCategory>("concept_gap");
  const [lastMistakeId, setLastMistakeId] = useState<string | null>(null);
  const [aiText, setAiText] = useState("");
  const started = useRef(Date.now());

  const weakTopicIds = useMemo(() => {
    const map = new Map<string, number>();
    for (const m of mistakes) {
      if (m.topicId) map.set(m.topicId, (map.get(m.topicId) ?? 0) + 1);
    }
    return new Set([...map.entries()].filter(([, n]) => n >= 2).map(([id]) => id));
  }, [mistakes]);

  const buildQueue = () => {
    let pool = all.slice();
    if (search.questionId) pool = pool.filter((q) => q.id === search.questionId);
    else {
      if (examId) pool = pool.filter((q) => q.examId === examId);
      if (topicId) pool = pool.filter((q) => q.topicId === topicId);
      if (difficulty !== "any") pool = pool.filter((q) => q.difficulty === difficulty);
      if (search.mode === "weak") {
        const weak = pool.filter((q) => q.topicId && weakTopicIds.has(q.topicId));
        if (weak.length) pool = weak;
      }
    }
    const picked = shuffle(pool).slice(0, Math.max(1, count));
    if (!picked.length) {
      toast.error("No questions match those filters.");
      return;
    }
    setQueue(picked);
    setIdx(0);
    setSetupDone(true);
    started.current = Date.now();
    setAnswer("");
    setRevealed(false);
    setCorrect(null);
    setConfidence(null);
  };

  useEffect(() => {
    if (setupDone && !queue.length && all.length) buildQueue();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [setupDone, all.length]);

  const q = queue[idx];

  const commit = async () => {
    if (!q) return;
    if (q.type === "mcq" || q.type === "tf") {
      if (!answer) {
        toast.error("Choose an answer first.");
        return;
      }
    } else if (!answer.trim()) {
      toast.error("Enter an answer first.");
      return;
    }
    const ok =
      q.type === "numerical" || q.type === "short" || q.type === "custom"
        ? numericalMatch(answer, q.correctAnswer) || answer.trim().toLowerCase() === q.correctAnswer.trim().toLowerCase()
        : answer === q.correctAnswer;
    const timeMs = Date.now() - started.current;
    const rec = await recordAttempt({
      question: q,
      answer,
      correct: ok,
      confidence,
      timeMs,
      sessionId: search.sessionId ?? null,
      mistakeCategory: ok ? null : mistakeCat,
    });
    setCorrect(ok);
    setRevealed(true);
    setLastMistakeId(rec.mistake?.id ?? null);
  };

  const next = () => {
    if (idx + 1 >= queue.length) {
      navigate({ to: "/practice" });
      return;
    }
    setIdx(idx + 1);
    setAnswer("");
    setRevealed(false);
    setCorrect(null);
    setConfidence(null);
    setAiText("");
    started.current = Date.now();
  };

  if (!setupDone) {
    return (
      <div className="mx-auto min-h-dvh max-w-lg px-4 py-6">
        <h1 className="font-display text-2xl font-medium">Practice setup</h1>
        <div className="mt-4 space-y-3">
          <NativeSelect value={examId} onChange={(e) => setExamId(e.target.value)}>
            <option value="">Any exam</option>
            {exams.map((e) => (
              <option key={e.id} value={e.id}>
                {e.name}
              </option>
            ))}
          </NativeSelect>
          <NativeSelect value={topicId} onChange={(e) => setTopicId(e.target.value)}>
            <option value="">Any topic</option>
            {topics
              .filter((t) => !examId || t.examId === examId)
              .map((t) => (
                <option key={t.id} value={t.id}>
                  {t.title}
                </option>
              ))}
          </NativeSelect>
          <NativeSelect value={difficulty} onChange={(e) => setDifficulty(e.target.value as Difficulty | "any")}>
            <option value="any">Any difficulty</option>
            <option value="easy">Easy</option>
            <option value="medium">Medium</option>
            <option value="hard">Hard</option>
          </NativeSelect>
          <label className="flex min-h-11 items-center gap-2 text-sm">
            <input type="checkbox" checked={timed} onChange={(e) => setTimed(e.target.checked)} />
            Timed (recorded)
          </label>
          <label className="block text-sm">
            Count
            <input
              type="number"
              min={1}
              max={50}
              className="mt-1 h-11 w-full rounded-lg bg-surface-2 px-3"
              value={count}
              onChange={(e) => setCount(Number(e.target.value))}
            />
          </label>
          <Button className="w-full" onClick={buildQueue}>
            Start
          </Button>
          <Button variant="ghost" className="w-full" onClick={() => navigate({ to: "/practice" })}>
            Cancel
          </Button>
        </div>
      </div>
    );
  }

  if (!q) {
    return (
      <div className="flex min-h-dvh flex-col items-center justify-center gap-3 px-6">
        <p className="text-muted">No questions in this set.</p>
        <Link to="/practice">
          <Button>Back</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto flex min-h-dvh max-w-lg flex-col px-4 py-4">
      <div className="mb-3 flex items-center justify-between text-xs text-muted">
        <span>
          {idx + 1} / {queue.length}
        </span>
        <span className="capitalize">
          {q.difficulty}
          {timed ? " · timed" : ""}
        </span>
      </div>
      <p className="font-display text-xl leading-snug">{q.stem}</p>
      {q.source === "ai" ? <p className="mt-1 text-[11px] text-subtle">Generated by AI — verify before trusting.</p> : null}

      <div className="mt-5 space-y-2">
        {(q.type === "mcq" || q.type === "tf") &&
          q.options.map((o) => {
            const selected = answer === o.id;
            const showKey = revealed && (o.id === q.correctAnswer || selected);
            return (
              <button
                key={o.id}
                type="button"
                disabled={revealed}
                onClick={() => setAnswer(o.id)}
                className={`flex min-h-12 w-full items-center rounded-2xl px-4 text-left text-sm shadow-[var(--shadow-border)] ${
                  selected ? "bg-ink text-paper" : "bg-surface"
                } ${revealed && o.id === q.correctAnswer ? "ring-2 ring-good" : ""} ${
                  revealed && selected && o.id !== q.correctAnswer ? "ring-2 ring-bad" : ""
                }`}
              >
                {o.text}
                {showKey && o.id === q.correctAnswer ? <span className="ml-auto text-[11px]">Correct</span> : null}
              </button>
            );
          })}
        {(q.type === "numerical" || q.type === "short" || q.type === "custom") && (
          <input
            className="h-12 w-full rounded-2xl bg-surface px-4 shadow-[var(--shadow-border)]"
            placeholder="Your answer"
            value={answer}
            disabled={revealed}
            onChange={(e) => setAnswer(e.target.value)}
          />
        )}
      </div>

      {!revealed ? (
        <div className="mt-6">
          <p className="mb-2 text-xs text-muted">Confidence before you commit</p>
          <div className="flex gap-1">
            {[1, 2, 3, 4, 5].map((n) => (
              <button
                key={n}
                type="button"
                onClick={() => setConfidence(n)}
                className={`h-11 flex-1 rounded-xl text-sm ${confidence === n ? "bg-ink text-paper" : "bg-surface-2"}`}
              >
                {n}
              </button>
            ))}
          </div>
          <Button className="mt-4 w-full" size="lg" onClick={commit}>
            Commit answer
          </Button>
        </div>
      ) : (
        <div className="mt-5 space-y-3">
          <Card className={correct ? "p-4" : "p-4"}>
            <p className="font-medium">{correct ? "Correct" : "Incorrect"}</p>
            <p className="mt-1 text-sm text-muted">Answer: {labelFor(q, q.correctAnswer)}</p>
            {q.explanation ? <p className="mt-2 text-sm">{q.explanation}</p> : null}
          </Card>
          {!correct ? (
            <div>
              <p className="mb-1 text-xs text-muted">Classify this mistake</p>
              <NativeSelect
                value={mistakeCat}
                onChange={async (e) => {
                  const v = e.target.value as MistakeCategory;
                  setMistakeCat(v);
                  if (lastMistakeId) await classifyMistake(lastMistakeId, v);
                }}
              >
                {MISTAKE_CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {MISTAKE_LABEL[c]}
                  </option>
                ))}
              </NativeSelect>
            </div>
          ) : null}
          <AiExplain question={q} onText={setAiText} />
          {aiText ? <p className="text-sm text-muted whitespace-pre-wrap">{aiText}</p> : null}
          <Button className="w-full" onClick={next}>
            {idx + 1 >= queue.length ? "Finish" : "Next"}
          </Button>
        </div>
      )}
    </div>
  );
}

function labelFor(q: Question, id: string) {
  return q.options.find((o) => o.id === id)?.text ?? id;
}

function AiExplain({ question, onText }: { question: Question; onText: (t: string) => void }) {
  const [busy, setBusy] = useState(false);
  const run = async (mode: "simple" | "professional" | "steps" | "trap" | "similar") => {
    setBusy(true);
    const res = await explainQuestion({
      data: {
        mode,
        stem: question.stem,
        options: question.options.map((o) => `${o.id}: ${o.text}`).join("; "),
        correctAnswer: question.correctAnswer,
        explanation: question.explanation,
        excerpts: "",
      },
    });
    setBusy(false);
    if (!res.ok) toast.error(res.error);
    else onText((mode === "similar" ? "Generated by AI\n\n" : "Generated by AI\n\n") + res.text);
  };
  return (
    <div className="flex flex-wrap gap-1.5">
      <Button size="sm" variant="outline" disabled={busy} onClick={() => run("simple")}>
        Explain simply
      </Button>
      <Button size="sm" variant="outline" disabled={busy} onClick={() => run("steps")}>
        Step-by-step
      </Button>
      <Button size="sm" variant="outline" disabled={busy} onClick={() => run("trap")}>
        Common trap
      </Button>
      <Button size="sm" variant="outline" disabled={busy} onClick={() => run("similar")}>
        Similar question
      </Button>
    </div>
  );
}
