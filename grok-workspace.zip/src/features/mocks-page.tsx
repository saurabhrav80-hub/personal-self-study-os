import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { EmptyState, Screen } from "@/components/ui/empty";
import { Field, Input, NativeSelect } from "@/components/ui/input";
import { useExams, useMockResults, useMocks, useQuestions, useTopics } from "@/lib/study/hooks";
import { createMock } from "@/lib/study/repo";
import { shuffle } from "@/lib/utils";
import type { Difficulty, MockKind } from "@/lib/study/types";

export function MocksPage() {
  const mocks = useMocks();
  const results = useMockResults();
  const exams = useExams();

  return (
    <Screen title="Mocks" action={<CreateMockButton />}>
      {mocks.length === 0 ? (
        <EmptyState
          title="No mock tests yet"
          body="Build a full, sectional, topic, or custom mock from your local question bank. Timing and scoring stay on this device."
          action={<CreateMockButton />}
        />
      ) : (
        <ul className="space-y-2">
          {mocks.map((m) => {
            const last = results.find((r) => r.mockId === m.id);
            return (
              <li key={m.id}>
                <Card className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-medium">{m.name}</p>
                      <p className="text-xs text-muted">
                        {m.kind} · {m.questionIds.length} questions · {m.timeLimitMin} min
                        {m.negativeMarking ? ` · −${m.negativeMarking}` : ""}
                      </p>
                      {last ? (
                        <p className="mt-1 text-xs text-muted">
                          Last: {Math.round(last.accuracy)}% accuracy · {last.score.toFixed(1)}/{last.maxScore}
                        </p>
                      ) : (
                        <p className="mt-1 text-xs text-subtle">Not attempted</p>
                      )}
                    </div>
                    <Link to="/mocks/run" search={{ mockId: m.id }}>
                      <Button size="sm">Start</Button>
                    </Link>
                  </div>
                  {last ? (
                    <Link to="/mocks/report/$resultId" params={{ resultId: last.id }} className="mt-2 inline-block text-xs text-muted">
                      Open last report
                    </Link>
                  ) : null}
                </Card>
              </li>
            );
          })}
        </ul>
      )}
    </Screen>
  );
}

function CreateMockButton() {
  const [open, setOpen] = useState(false);
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm">New mock</Button>
      </DialogTrigger>
      <DialogContent title="Create mock">
        <CreateMockForm onDone={() => setOpen(false)} />
      </DialogContent>
    </Dialog>
  );
}

function CreateMockForm({ onDone }: { onDone: () => void }) {
  const exams = useExams();
  const questions = useQuestions();
  const topics = useTopics();
  const [name, setName] = useState("Mock");
  const [kind, setKind] = useState<MockKind>("full");
  const [examId, setExamId] = useState(exams[0]?.id ?? "");
  const [topicId, setTopicId] = useState("");
  const [count, setCount] = useState(10);
  const [minutes, setMinutes] = useState(20);
  const [neg, setNeg] = useState(0.33);
  const [diff, setDiff] = useState<Difficulty | "mixed">("mixed");

  const submit = async () => {
    let pool = questions.filter((q) => !examId || q.examId === examId);
    if (kind === "topic" && topicId) pool = pool.filter((q) => q.topicId === topicId);
    if (diff !== "mixed") pool = pool.filter((q) => q.difficulty === diff);
    const picked = shuffle(pool).slice(0, count).map((q) => q.id);
    if (picked.length < 3) {
      toast.error("Need at least 3 matching questions in the bank.");
      return;
    }
    if (picked.length < count) {
      toast.message(`Only ${picked.length} questions matched. Using those.`);
    }
    const sections =
      kind === "sectional" && examId
        ? groupSections(picked, questions.filter((q) => picked.includes(q.id)))
        : [];
    await createMock({
      name: name.trim() || "Mock",
      kind,
      examId: examId || null,
      questionIds: picked,
      timeLimitMin: minutes,
      negativeMarking: neg,
      marksCorrect: 1,
      sections,
      difficulty: diff,
    });
    toast.success("Mock saved locally.");
    onDone();
  };

  return (
    <div className="space-y-3">
      <Field label="Name">
        <Input value={name} onChange={(e) => setName(e.target.value)} />
      </Field>
      <Field label="Type">
        <NativeSelect value={kind} onChange={(e) => setKind(e.target.value as MockKind)}>
          <option value="full">Full mock</option>
          <option value="sectional">Sectional</option>
          <option value="topic">Topic</option>
          <option value="custom">Custom</option>
        </NativeSelect>
      </Field>
      <Field label="Exam">
        <NativeSelect value={examId} onChange={(e) => setExamId(e.target.value)}>
          <option value="">Any</option>
          {exams.map((e) => (
            <option key={e.id} value={e.id}>
              {e.name}
            </option>
          ))}
        </NativeSelect>
      </Field>
      {kind === "topic" ? (
        <Field label="Topic">
          <NativeSelect value={topicId} onChange={(e) => setTopicId(e.target.value)}>
            <option value="">Select</option>
            {topics
              .filter((t) => !examId || t.examId === examId)
              .map((t) => (
                <option key={t.id} value={t.id}>
                  {t.title}
                </option>
              ))}
          </NativeSelect>
        </Field>
      ) : null}
      <Field label="Questions">
        <Input type="number" value={count} onChange={(e) => setCount(Number(e.target.value))} />
      </Field>
      <Field label="Time (minutes)">
        <Input type="number" value={minutes} onChange={(e) => setMinutes(Number(e.target.value))} />
      </Field>
      <Field label="Negative mark (per wrong)">
        <Input type="number" step="0.01" value={neg} onChange={(e) => setNeg(Number(e.target.value))} />
      </Field>
      <Field label="Difficulty">
        <NativeSelect value={diff} onChange={(e) => setDiff(e.target.value as Difficulty | "mixed")}>
          <option value="mixed">Mixed</option>
          <option value="easy">Easy</option>
          <option value="medium">Medium</option>
          <option value="hard">Hard</option>
        </NativeSelect>
      </Field>
      <Button className="w-full" onClick={submit}>
        Create
      </Button>
    </div>
  );
}

function groupSections(ids: string[], questions: { id: string; subjectId: string | null; examId: string | null }[]) {
  const map = new Map<string, string[]>();
  for (const id of ids) {
    const q = questions.find((x) => x.id === id);
    const key = q?.subjectId ?? "Section";
    const list = map.get(key) ?? [];
    list.push(id);
    map.set(key, list);
  }
  return [...map.entries()].map(([name, questionIds]) => ({
    name: name === "Section" ? "Main" : name,
    questionIds,
    timeMin: null as number | null,
  }));
}
