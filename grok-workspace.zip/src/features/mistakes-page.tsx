import { Link } from "@tanstack/react-router";
import { NativeSelect } from "@/components/ui/input";
import { EmptyState, Screen, SectionLabel } from "@/components/ui/empty";
import { whyLosingMarks } from "@/lib/study/engines";
import { MISTAKE_CATEGORIES, MISTAKE_LABEL, type MistakeCategory } from "@/lib/study/types";
import { useMistakes, useQuestions, useTopics } from "@/lib/study/hooks";
import { classifyMistake } from "@/lib/study/repo";
import { useMemo, useState } from "react";

export function MistakesPage() {
  const mistakes = useMistakes();
  const questions = useQuestions();
  const topics = useTopics();
  const [cat, setCat] = useState<MistakeCategory | "all">("all");
  const qmap = useMemo(() => new Map(questions.map((q) => [q.id, q])), [questions]);
  const tmap = useMemo(() => new Map(topics.map((t) => [t.id, t])), [topics]);
  const cats = whyLosingMarks(mistakes);
  const byTopic = useMemo(() => {
    const m = new Map<string, number>();
    for (const x of mistakes) {
      if (!x.topicId) continue;
      m.set(x.topicId, (m.get(x.topicId) ?? 0) + 1);
    }
    return [...m.entries()].sort((a, b) => b[1] - a[1]);
  }, [mistakes]);
  const shown = cat === "all" ? mistakes : mistakes.filter((m) => m.category === cat);

  return (
    <Screen title="Mistakes">
      <p className="mb-4 text-sm text-muted">Why am I losing marks? — from your own classified errors, not a generic list.</p>
      {mistakes.length === 0 ? (
        <EmptyState title="No mistakes recorded" body="Incorrect practice and mock answers appear here once you classify them." />
      ) : (
        <>
          <SectionLabel>Top leak categories</SectionLabel>
          <ul className="mb-4 space-y-1">
            {cats.slice(0, 6).map((c) => (
              <li key={c.category} className="flex justify-between text-sm">
                <span>{MISTAKE_LABEL[c.category as MistakeCategory] ?? c.category}</span>
                <span className="tabular">{c.count}</span>
              </li>
            ))}
          </ul>
          <SectionLabel>Topics</SectionLabel>
          <ul className="mb-4 space-y-1">
            {byTopic.slice(0, 8).map(([id, n]) => (
              <li key={id}>
                <Link to="/practice/run" search={{ mode: "topic", topicId: id }} className="flex justify-between text-sm">
                  <span>{tmap.get(id)?.title ?? "Topic"}</span>
                  <span className="tabular">{n}</span>
                </Link>
              </li>
            ))}
          </ul>
          <NativeSelect className="mb-3" value={cat} onChange={(e) => setCat(e.target.value as MistakeCategory | "all")}>
            <option value="all">All categories</option>
            {MISTAKE_CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {MISTAKE_LABEL[c]}
              </option>
            ))}
          </NativeSelect>
          <ul className="space-y-2">
            {shown.map((m) => {
              const q = qmap.get(m.questionId);
              return (
                <li key={m.id} className="rounded-2xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]">
                  <p className="text-sm">{q?.stem ?? "Question removed"}</p>
                  <p className="mt-1 text-xs text-muted">
                    You: {m.userAnswer} · Correct: {m.correctAnswer} · {Math.round(m.timeMs / 1000)}s
                  </p>
                  <NativeSelect
                    className="mt-2"
                    value={m.category}
                    onChange={(e) => classifyMistake(m.id, e.target.value as MistakeCategory)}
                  >
                    {MISTAKE_CATEGORIES.map((c) => (
                      <option key={c} value={c}>
                        {MISTAKE_LABEL[c]}
                      </option>
                    ))}
                  </NativeSelect>
                </li>
              );
            })}
          </ul>
        </>
      )}
    </Screen>
  );
}
