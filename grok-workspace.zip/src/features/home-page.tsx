import { Link } from "@tanstack/react-router";
import { ArrowRight, Play } from "lucide-react";
import { AppLink } from "@/components/app-link";
import { ReadinessRing } from "@/components/status-chip";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { EmptyState, Screen, SectionLabel } from "@/components/ui/empty";
import { buildPriorities } from "@/lib/study/engines";
import {
  useAttempts,
  useBooks,
  useExams,
  useKnowledgeMap,
  useMistakes,
  useQuestions,
  useReadiness,
  useRevisions,
  useSettingsLive,
  useTopics,
} from "@/lib/study/hooks";
import { greeting, relativeDay } from "@/lib/utils";

export function HomePage() {
  const exams = useExams();
  const books = useBooks();
  const topics = useTopics();
  const knowledge = useKnowledgeMap();
  const mistakes = useMistakes();
  const revisions = useRevisions();
  const questions = useQuestions();
  const attempts = useAttempts();
  const readiness = useReadiness();
  const settings = useSettingsLive();

  const priorities = buildPriorities({
    exams,
    topics,
    knowledgeByTopic: knowledge,
    mistakes,
    revisions,
    questions,
    attempts,
    booksCount: books.length,
  });

  const hour = greeting();
  const name = settings?.displayName?.trim();

  return (
    <Screen wide>
      <div className="mb-6">
        <p className="text-sm text-muted">
          {hour}
          {name ? `, ${name}` : ""}
        </p>
        <h1 className="mt-1 font-display text-3xl font-medium tracking-tight">What should you study now?</h1>
      </div>

      <SectionLabel>Today's priorities</SectionLabel>
      {priorities.length === 0 ? (
        <EmptyState
          title="Nothing queued"
          body="Add an exam, upload a book, or run a practice set and this list will fill from your actual data."
        />
      ) : (
        <ol className="mb-8 space-y-2">
          {priorities.map((p, i) => (
            <li key={p.id}>
              <AppLink
                href={p.href}
                className="flex min-h-14 items-center gap-3 rounded-2xl bg-surface px-4 py-3 shadow-[var(--shadow-border)]"
              >
                <span className="tabular w-6 font-display text-lg text-subtle">{i + 1}</span>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium text-fg">{p.title}</p>
                  <p className="truncate text-xs text-muted">
                    {p.examName ? `${p.examName} · ` : ""}
                    {p.reason}
                  </p>
                </div>
                <ArrowRight className="size-4 shrink-0 text-subtle" />
              </AppLink>
            </li>
          ))}
        </ol>
      )}

      <div className="mb-8 flex gap-2">
        <Link to="/session" className="flex-1">
          <Button className="w-full" size="lg">
            <Play className="size-4" />
            Start session
          </Button>
        </Link>
        <Link to="/practice" className="flex-1">
          <Button className="w-full" variant="secondary" size="lg">
            Practice
          </Button>
        </Link>
      </div>

      <SectionLabel>Exam readiness</SectionLabel>
      {exams.length === 0 ? (
        <EmptyState
          title="No exams yet"
          body="Add CFA, CAT, GRE, or any other exam in settings."
          action={
            <Link to="/settings">
              <Button>Add exam</Button>
            </Link>
          }
        />
      ) : (
        <div className="grid gap-3 sm:grid-cols-3">
          {exams.map((exam) => {
            const r = readiness.find((x) => x.examId === exam.id);
            return (
              <Card key={exam.id} className="p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-display text-xl font-medium">{exam.name}</p>
                    <p className="mt-1 text-xs text-muted">
                      {exam.date ? `Exam ${relativeDay(exam.date)}` : "Date not set"}
                    </p>
                  </div>
                  <ReadinessRing value={r?.overall ?? null} />
                </div>
                <dl className="mt-4 grid grid-cols-2 gap-x-3 gap-y-2 text-xs">
                  <Stat label="Topics done" value={`${r?.topicsCompleted ?? 0}/${r?.topicsTotal ?? 0}`} />
                  <Stat label="Weak" value={`${r?.topicsWeak ?? 0}`} />
                  <Stat label="Revision due" value={`${r?.revisionDue ?? 0}`} />
                  <Stat label="Accuracy" value={r?.accuracy == null ? "—" : `${r.accuracy}%`} />
                </dl>
                <p className="mt-3 text-[11px] text-subtle">
                  Readiness is not syllabus completion. It weights knowledge, accuracy, speed, retention, mocks, and
                  weak topics.
                </p>
              </Card>
            );
          })}
        </div>
      )}

      <div className="mt-6 grid grid-cols-2 gap-2 sm:grid-cols-4">
        <MiniLink to="/mocks" label="Mocks" />
        <MiniLink to="/mistakes" label="Mistakes" />
        <MiniLink to="/formulas" label="Formulas" />
        <MiniLink to="/notes" label="Notes" />
      </div>
    </Screen>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-subtle">{label}</dt>
      <dd className="tabular font-medium text-fg">{value}</dd>
    </div>
  );
}

function MiniLink({ to, label }: { to: "/mocks" | "/mistakes" | "/formulas" | "/notes"; label: string }) {
  return (
    <Link
      to={to}
      className="flex min-h-12 items-center justify-center rounded-xl bg-surface text-sm font-medium shadow-[var(--shadow-border)]"
    >
      {label}
    </Link>
  );
}
