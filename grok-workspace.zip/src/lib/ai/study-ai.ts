import { createServerFn } from "@tanstack/react-start";

type ChatOk = { ok: true; text: string };
type ChatErr = { ok: false; error: string };
export type ChatResult = ChatOk | ChatErr;

async function chat(messages: { role: "system" | "user" | "assistant"; content: string }[], maxTokens = 900): Promise<ChatResult> {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return { ok: false, error: "AI is not available in this environment." };

  const res = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "grok-4.5",
      messages,
      max_tokens: maxTokens,
      temperature: 0.3,
    }),
  });
  if (!res.ok) return { ok: false, error: `xAI API error ${res.status}` };
  const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  return { ok: true, text: body.choices?.[0]?.message?.content ?? "" };
}

export const askMyBooks = createServerFn({ method: "POST" })
  .inputValidator((input: { question: string; excerpts: { bookName: string; chapterTitle: string | null; page: number; text: string }[] }) => input)
  .handler(async ({ data }): Promise<ChatResult> => {
    if (!data.excerpts.length) {
      return { ok: false, error: "I couldn't find this in your uploaded material." };
    }
    const packed = data.excerpts
      .map(
        (e, i) =>
          `[${i + 1}] ${e.bookName}${e.chapterTitle ? " → " + e.chapterTitle : ""} → p.${e.page}\n${e.text}`,
      )
      .join("\n\n");
    return chat(
      [
        {
          role: "system",
          content:
            "You are a book-grounded study assistant. Answer ONLY from the provided excerpts. Cite sources as Book → Chapter → Page using the labels given. If the excerpts are insufficient, say exactly: I couldn't find this in your uploaded material. Never invent page numbers, quotes, or citations. Label nothing as fact beyond the excerpts.",
        },
        {
          role: "user",
          content: `Question: ${data.question}\n\nExcerpts:\n${packed}`,
        },
      ],
      800,
    );
  });

export const generateChapterQuestions = createServerFn({ method: "POST" })
  .inputValidator(
    (input: {
      chapterTitle: string;
      bookName: string;
      difficulty: "easy" | "medium" | "hard" | "mixed";
      text: string;
    }) => input,
  )
  .handler(async ({ data }): Promise<ChatResult> => {
    if (data.text.trim().length < 80) {
      return { ok: false, error: "Not enough extracted text in this chapter to ground questions." };
    }
    return chat(
      [
        {
          role: "system",
          content:
            'Create 5 practice questions strictly grounded in the chapter text. Return JSON only: {"questions":[{"type":"mcq"|"numerical"|"tf","stem":"","options":[{"id":"a","text":""}],"correctAnswer":"a","explanation":"","difficulty":"easy"|"medium"|"hard"}]}. MCQ must have 4 options. Do not invent facts absent from the text. Prefix nothing else.',
        },
        {
          role: "user",
          content: `Book: ${data.bookName}\nChapter: ${data.chapterTitle}\nDifficulty: ${data.difficulty}\n\nText:\n${data.text.slice(0, 6000)}`,
        },
      ],
      1600,
    );
  });

export const explainQuestion = createServerFn({ method: "POST" })
  .inputValidator(
    (input: {
      mode: "simple" | "professional" | "steps" | "trap" | "similar";
      stem: string;
      options: string;
      correctAnswer: string;
      explanation: string;
      excerpts: string;
    }) => input,
  )
  .handler(async ({ data }): Promise<ChatResult> => {
    const style =
      data.mode === "simple"
        ? "Explain simply, as if to a peer who missed one lecture. Short paragraphs."
        : data.mode === "professional"
          ? "Explain professionally, exam-ready language, no fluff."
          : data.mode === "steps"
            ? "Explain step by step. Number the steps."
            : data.mode === "trap"
              ? "Show the common trap that leads to a wrong option. Be specific."
              : "Write ONE similar original question (stem, options, answer, explanation) of the same difficulty. Do not copy the original stem.";
    return chat(
      [
        {
          role: "system",
          content: `You help a CFA/CAT/GRE self-study student. ${style} If book excerpts are provided, prefer them and cite Book → Chapter → Page. If they are missing, use general reasoning and label it as general reasoning, not as coming from the user's books. Never invent citations.`,
        },
        {
          role: "user",
          content: `Question: ${data.stem}\nOptions: ${data.options}\nCorrect: ${data.correctAnswer}\nStored explanation: ${data.explanation || "(none)"}\nExcerpts:\n${data.excerpts || "(none)"}`,
        },
      ],
      700,
    );
  });
