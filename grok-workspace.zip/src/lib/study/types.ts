export type TopicStatus =
  | "not_started"
  | "reading"
  | "read"
  | "practiced"
  | "revised"
  | "strong"
  | "mastered";

export type QuestionType = "mcq" | "numerical" | "tf" | "short" | "custom";
export type Difficulty = "easy" | "medium" | "hard";
export type QuestionSource = "user" | "starter" | "ai";

export type MistakeCategory =
  | "concept_gap"
  | "formula_error"
  | "calculation_error"
  | "misread"
  | "careless"
  | "time_pressure"
  | "wrong_approach"
  | "guess"
  | "memory_failure"
  | "other";

export type NoteType = "text" | "concept" | "question" | "mistake" | "book" | "revision";
export type MockKind = "full" | "sectional" | "topic" | "custom";
export type RecallResult = "knew" | "partial" | "forgot";
export type ThemeMode = "light" | "dark" | "system";
export type RevisionKind = "topic" | "concept" | "formula" | "question" | "note";
export type ExtractionStatus = "idle" | "running" | "ok" | "failed" | "manual";

export const TOPIC_STATUS_LABEL: Record<TopicStatus, string> = {
  not_started: "Not started",
  reading: "Reading",
  read: "Read",
  practiced: "Practiced",
  revised: "Revised",
  strong: "Strong",
  mastered: "Mastered",
};

export const STATUS_ORDER: TopicStatus[] = [
  "not_started",
  "reading",
  "read",
  "practiced",
  "revised",
  "strong",
  "mastered",
];

export const MISTAKE_LABEL: Record<MistakeCategory, string> = {
  concept_gap: "Concept gap",
  formula_error: "Formula error",
  calculation_error: "Calculation error",
  misread: "Misread question",
  careless: "Careless mistake",
  time_pressure: "Time pressure",
  wrong_approach: "Wrong approach",
  guess: "Guess",
  memory_failure: "Memory failure",
  other: "Other",
};

export const MISTAKE_CATEGORIES = Object.keys(MISTAKE_LABEL) as MistakeCategory[];

export interface Exam {
  id: string;
  name: string;
  date: number | null;
  priority: number;
  targetScore: number | null;
  active: boolean;
  createdAt: number;
}

export interface Subject {
  id: string;
  examId: string;
  name: string;
  weight: number;
}

export interface Book {
  id: string;
  examId: string | null;
  subjectId: string | null;
  name: string;
  author: string;
  edition: string;
  fileName: string;
  mimeType: string;
  size: number;
  pageCount: number;
  lastPage: number;
  lastOpenedAt: number | null;
  readingProgress: number;
  completionStatus: "unread" | "reading" | "complete";
  extractionStatus: ExtractionStatus;
  extractionNote: string;
  createdAt: number;
}

export interface BookFile {
  bookId: string;
  blob: Blob;
  mimeType: string;
}

export interface Chapter {
  id: string;
  bookId: string;
  title: string;
  pageStart: number;
  pageEnd: number;
  order: number;
  status: TopicStatus;
}

export interface Topic {
  id: string;
  chapterId: string | null;
  bookId: string | null;
  examId: string | null;
  subjectId: string | null;
  title: string;
  pageStart: number | null;
  pageEnd: number | null;
  order: number;
  status: TopicStatus;
  importance: number;
  lastStudiedAt: number | null;
  lastRevisedAt: number | null;
  nextRevisionAt: number | null;
  createdAt: number;
}

export interface Concept {
  id: string;
  name: string;
  aliases: string[];
  examIds: string[];
  topicIds: string[];
  summary: string;
  createdAt: number;
}

export interface ConceptLink {
  id: string;
  fromId: string;
  toId: string;
  relation: "related" | "prerequisite" | "applies_to";
}

export interface Note {
  id: string;
  type: NoteType;
  title: string;
  body: string;
  examId: string | null;
  bookId: string | null;
  chapterId: string | null;
  topicId: string | null;
  questionId: string | null;
  conceptId: string | null;
  createdAt: number;
  updatedAt: number;
}

export interface FormulaVar {
  symbol: string;
  name: string;
}

export interface Formula {
  id: string;
  name: string;
  formula: string;
  meaning: string;
  variables: FormulaVar[];
  example: string;
  whenToUse: string;
  commonMistake: string;
  examIds: string[];
  category: string;
  relatedConceptIds: string[];
  createdAt: number;
}

export interface QuestionOption {
  id: string;
  text: string;
}

export interface Question {
  id: string;
  type: QuestionType;
  stem: string;
  options: QuestionOption[];
  correctAnswer: string;
  explanation: string;
  examId: string | null;
  subjectId: string | null;
  chapterId: string | null;
  topicId: string | null;
  bookId: string | null;
  page: number | null;
  difficulty: Difficulty;
  source: QuestionSource;
  tags: string[];
  createdAt: number;
}

export interface Attempt {
  id: string;
  questionId: string;
  sessionId: string | null;
  mockResultId: string | null;
  answer: string;
  correct: boolean;
  confidence: number | null;
  timeMs: number;
  createdAt: number;
}

export interface Mistake {
  id: string;
  questionId: string;
  attemptId: string;
  userAnswer: string;
  correctAnswer: string;
  category: MistakeCategory;
  topicId: string | null;
  examId: string | null;
  difficulty: Difficulty | null;
  timeMs: number;
  notes: string;
  createdAt: number;
}

export interface RevisionItem {
  id: string;
  kind: RevisionKind;
  refId: string;
  examId: string | null;
  topicId: string | null;
  prompt: string;
  answer: string;
  dueAt: number;
  intervalDays: number;
  ease: number;
  repetitions: number;
  lastResult: RecallResult | null;
  createdAt: number;
  lastReviewedAt: number | null;
}

export interface StudySession {
  id: string;
  examId: string | null;
  topicId: string | null;
  bookId: string | null;
  title: string;
  startedAt: number;
  endedAt: number | null;
  plannedMin: number;
  questionsSolved: number;
  correctCount: number;
  notesCreated: number;
  revisionsCreated: number;
}

export interface MockSection {
  name: string;
  questionIds: string[];
  timeMin: number | null;
}

export interface MockTest {
  id: string;
  name: string;
  kind: MockKind;
  examId: string | null;
  questionIds: string[];
  timeLimitMin: number;
  negativeMarking: number;
  marksCorrect: number;
  sections: MockSection[];
  difficulty: Difficulty | "mixed";
  createdAt: number;
}

export interface MockAnswer {
  questionId: string;
  answer: string;
  timeMs: number;
  marked: boolean;
  skipped: boolean;
}

export interface MockResult {
  id: string;
  mockId: string;
  startedAt: number;
  submittedAt: number;
  answers: MockAnswer[];
  score: number;
  maxScore: number;
  accuracy: number;
  attemptRate: number;
  timeEfficiency: number;
}

export interface Highlight {
  id: string;
  bookId: string;
  page: number;
  text: string;
  color: "ink" | "olive" | "amber";
  note: string;
  createdAt: number;
}

export interface Bookmark {
  id: string;
  bookId: string;
  page: number;
  title: string;
  createdAt: number;
}

export interface PageText {
  bookId: string;
  page: number;
  text: string;
}

export interface ReadinessWeights {
  knowledge: number;
  accuracy: number;
  speed: number;
  retention: number;
  mock: number;
  weak: number;
}

export const DEFAULT_WEIGHTS: ReadinessWeights = {
  knowledge: 25,
  accuracy: 20,
  speed: 10,
  retention: 15,
  mock: 20,
  weak: 10,
};

export interface AppSettings {
  id: "settings";
  theme: ThemeMode;
  displayName: string;
  onboardingComplete: boolean;
  seedVersion: number;
  targetTimes: Record<string, number>;
  readinessWeights: ReadinessWeights;
  includeStarterContent: boolean;
}

export interface SearchHit {
  id: string;
  kind:
    | "book"
    | "chapter"
    | "topic"
    | "question"
    | "mistake"
    | "note"
    | "formula"
    | "concept"
    | "mock"
    | "page";
  title: string;
  snippet: string;
  href: string;
  examId: string | null;
}

export interface PriorityItem {
  id: string;
  title: string;
  reason: string;
  href: string;
  examName: string | null;
  urgency: "now" | "today" | "soon";
}

export interface ReadinessBreakdown {
  examId: string;
  overall: number | null;
  knowledge: number | null;
  accuracy: number | null;
  speed: number | null;
  retention: number | null;
  mock: number | null;
  weak: number | null;
  topicsTotal: number;
  topicsCompleted: number;
  topicsWeak: number;
  revisionDue: number;
}

export type SpeedPattern = "speed" | "concept" | "major" | "strong" | "neutral";

export interface TopicAnalytics {
  topicId: string;
  title: string;
  examId: string | null;
  questions: number;
  correct: number;
  accuracy: number;
  avgTimeMs: number;
  hardAccuracy: number | null;
  easyAccuracy: number | null;
  pattern: SpeedPattern;
}

export interface BookExcerpt {
  bookId: string;
  bookName: string;
  chapterTitle: string | null;
  page: number;
  text: string;
}
