import { downloadBlob } from "@/lib/utils";
import { requireDb } from "./db";

const BACKUP_VERSION = 1;

export async function exportBackup(includeFiles: boolean) {
  const db = requireDb();
  const [
    exams,
    subjects,
    books,
    chapters,
    topics,
    concepts,
    conceptLinks,
    notes,
    formulas,
    questions,
    attempts,
    mistakes,
    revisionItems,
    studySessions,
    mocks,
    mockResults,
    highlights,
    bookmarks,
    pageTexts,
    settings,
  ] = await Promise.all([
    db.exams.toArray(),
    db.subjects.toArray(),
    db.books.toArray(),
    db.chapters.toArray(),
    db.topics.toArray(),
    db.concepts.toArray(),
    db.conceptLinks.toArray(),
    db.notes.toArray(),
    db.formulas.toArray(),
    db.questions.toArray(),
    db.attempts.toArray(),
    db.mistakes.toArray(),
    db.revisionItems.toArray(),
    db.studySessions.toArray(),
    db.mocks.toArray(),
    db.mockResults.toArray(),
    db.highlights.toArray(),
    db.bookmarks.toArray(),
    db.pageTexts.toArray(),
    db.settings.toArray(),
  ]);

  const payload: Record<string, unknown> = {
    app: "personal-self-study-os",
    version: BACKUP_VERSION,
    exportedAt: new Date().toISOString(),
    exams,
    subjects,
    books,
    chapters,
    topics,
    concepts,
    conceptLinks,
    notes,
    formulas,
    questions,
    attempts,
    mistakes,
    revisionItems,
    studySessions,
    mocks,
    mockResults,
    highlights,
    bookmarks,
    pageTexts,
    settings,
  };

  if (includeFiles) {
    const files = await db.bookFiles.toArray();
    const encoded = [];
    for (const f of files) {
      const buf = await f.blob.arrayBuffer();
      encoded.push({
        bookId: f.bookId,
        mimeType: f.mimeType,
        data: arrayBufferToBase64(buf),
      });
    }
    payload.bookFiles = encoded;
  }

  const blob = new Blob([JSON.stringify(payload)], { type: "application/json" });
  const stamp = new Date().toISOString().slice(0, 10);
  downloadBlob(blob, `study-os-backup-${stamp}.json`);
}

export async function importBackup(file: File): Promise<{ restored: string[] }> {
  const text = await file.text();
  let data: Record<string, unknown>;
  try {
    data = JSON.parse(text) as Record<string, unknown>;
  } catch {
    throw new Error("That file is not valid JSON.");
  }
  if (data.app !== "personal-self-study-os") {
    throw new Error("This JSON is not a Personal Self-Study OS backup.");
  }
  const db = requireDb();
  const restored: string[] = [];

  const load = async <T>(key: string, table: { bulkPut: (rows: T[]) => Promise<unknown> }) => {
    const rows = data[key];
    if (!Array.isArray(rows) || !rows.length) return;
    await table.bulkPut(rows as T[]);
    restored.push(`${key} (${rows.length})`);
  };

  await db.transaction(
    "rw",
    [
      db.exams,
      db.subjects,
      db.books,
      db.chapters,
      db.topics,
      db.concepts,
      db.conceptLinks,
      db.notes,
      db.formulas,
      db.questions,
      db.attempts,
      db.mistakes,
      db.revisionItems,
      db.studySessions,
      db.mocks,
      db.mockResults,
      db.highlights,
      db.bookmarks,
      db.pageTexts,
      db.settings,
      db.bookFiles,
    ],
    async () => {
      await load("exams", db.exams);
      await load("subjects", db.subjects);
      await load("books", db.books);
      await load("chapters", db.chapters);
      await load("topics", db.topics);
      await load("concepts", db.concepts);
      await load("conceptLinks", db.conceptLinks);
      await load("notes", db.notes);
      await load("formulas", db.formulas);
      await load("questions", db.questions);
      await load("attempts", db.attempts);
      await load("mistakes", db.mistakes);
      await load("revisionItems", db.revisionItems);
      await load("studySessions", db.studySessions);
      await load("mocks", db.mocks);
      await load("mockResults", db.mockResults);
      await load("highlights", db.highlights);
      await load("bookmarks", db.bookmarks);
      await load("pageTexts", db.pageTexts);
      await load("settings", db.settings);
    },
  );

  const files = data.bookFiles;
  if (Array.isArray(files)) {
    for (const f of files as { bookId: string; mimeType: string; data: string }[]) {
      if (!f?.bookId || !f.data) continue;
      const blob = new Blob([base64ToBytes(f.data)], { type: f.mimeType || "application/pdf" });
      await db.bookFiles.put({ bookId: f.bookId, blob, mimeType: f.mimeType });
    }
    restored.push(`book files (${files.length})`);
  }

  return { restored };
}

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  const chunk = 0x8000;
  let binary = "";
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

function base64ToBytes(b64: string): ArrayBuffer {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}
