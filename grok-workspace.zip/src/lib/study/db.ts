import Dexie, { type Table } from "dexie";
import type {
  AppSettings,
  Attempt,
  Book,
  BookFile,
  Bookmark,
  Chapter,
  Concept,
  ConceptLink,
  Exam,
  Formula,
  Highlight,
  Mistake,
  MockResult,
  MockTest,
  Note,
  PageText,
  Question,
  RevisionItem,
  StudySession,
  Subject,
  Topic,
} from "./types";

export class StudyDB extends Dexie {
  exams!: Table<Exam, string>;
  subjects!: Table<Subject, string>;
  books!: Table<Book, string>;
  bookFiles!: Table<BookFile, string>;
  chapters!: Table<Chapter, string>;
  topics!: Table<Topic, string>;
  concepts!: Table<Concept, string>;
  conceptLinks!: Table<ConceptLink, string>;
  notes!: Table<Note, string>;
  formulas!: Table<Formula, string>;
  questions!: Table<Question, string>;
  attempts!: Table<Attempt, string>;
  mistakes!: Table<Mistake, string>;
  revisionItems!: Table<RevisionItem, string>;
  studySessions!: Table<StudySession, string>;
  mocks!: Table<MockTest, string>;
  mockResults!: Table<MockResult, string>;
  highlights!: Table<Highlight, string>;
  bookmarks!: Table<Bookmark, string>;
  pageTexts!: Table<PageText, [string, number]>;
  settings!: Table<AppSettings, string>;

  constructor() {
    super("personal-self-study-os");
    this.version(1).stores({
      exams: "id, name, date, priority, active",
      subjects: "id, examId, name",
      books: "id, examId, subjectId, name, lastOpenedAt, createdAt",
      bookFiles: "bookId",
      chapters: "id, bookId, order",
      topics: "id, chapterId, bookId, examId, subjectId, nextRevisionAt, status",
      concepts: "id, name",
      conceptLinks: "id, fromId, toId",
      notes: "id, type, examId, bookId, topicId, questionId, updatedAt",
      formulas: "id, name, category",
      questions: "id, examId, topicId, subjectId, difficulty, type, source, createdAt",
      attempts: "id, questionId, sessionId, mockResultId, createdAt, correct",
      mistakes: "id, questionId, category, topicId, examId, createdAt",
      revisionItems: "id, kind, refId, examId, topicId, dueAt",
      studySessions: "id, examId, topicId, startedAt",
      mocks: "id, examId, kind, createdAt",
      mockResults: "id, mockId, submittedAt",
      highlights: "id, bookId, page",
      bookmarks: "id, bookId, page",
      pageTexts: "[bookId+page], bookId, page",
      settings: "id",
    });
  }
}

let instance: StudyDB | null = null;

export function getDb(): StudyDB | null {
  if (typeof indexedDB === "undefined") return null;
  if (!instance) instance = new StudyDB();
  return instance;
}

export function requireDb(): StudyDB {
  const db = getDb();
  if (!db) throw new Error("Local database is only available in the browser.");
  return db;
}
