import MiniSearch from "minisearch";
import { getDb } from "./db";
import { searchPages } from "./pdf";
import type { SearchHit } from "./types";

export async function globalSearch(query: string): Promise<SearchHit[]> {
  const q = query.trim();
  if (q.length < 2) return [];
  const db = getDb();
  if (!db) return [];

  const [books, chapters, topics, questions, mistakes, notes, formulas, concepts, mocks] =
    await Promise.all([
      db.books.toArray(),
      db.chapters.toArray(),
      db.topics.toArray(),
      db.questions.toArray(),
      db.mistakes.toArray(),
      db.notes.toArray(),
      db.formulas.toArray(),
      db.concepts.toArray(),
      db.mocks.toArray(),
    ]);

  const docs: (SearchHit & { body: string })[] = [];

  for (const b of books) {
    docs.push({
      id: `book:${b.id}`,
      kind: "book",
      title: b.name,
      snippet: [b.author, b.edition].filter(Boolean).join(" · "),
      href: `/library/${b.id}`,
      examId: b.examId,
      body: `${b.name} ${b.author} ${b.fileName} ${b.extractionNote}`,
    });
  }
  for (const c of chapters) {
    docs.push({
      id: `ch:${c.id}`,
      kind: "chapter",
      title: c.title,
      snippet: `Pages ${c.pageStart}–${c.pageEnd}`,
      href: `/library/${c.bookId}`,
      examId: null,
      body: c.title,
    });
  }
  for (const t of topics) {
    docs.push({
      id: `topic:${t.id}`,
      kind: "topic",
      title: t.title,
      snippet: t.status.replace("_", " "),
      href: t.bookId ? `/library/${t.bookId}` : "/practice",
      examId: t.examId,
      body: t.title,
    });
  }
  for (const qu of questions) {
    docs.push({
      id: `q:${qu.id}`,
      kind: "question",
      title: qu.stem.slice(0, 110),
      snippet: `${qu.difficulty} · ${qu.type}`,
      href: `/practice/run?mode=id&questionId=${qu.id}`,
      examId: qu.examId,
      body: `${qu.stem} ${qu.explanation} ${qu.tags.join(" ")} ${qu.options.map((o) => o.text).join(" ")}`,
    });
  }
  const qmap = new Map(questions.map((x) => [x.id, x]));
  for (const m of mistakes) {
    const stem = qmap.get(m.questionId)?.stem ?? "Mistake";
    docs.push({
      id: `m:${m.id}`,
      kind: "mistake",
      title: stem.slice(0, 110),
      snippet: m.category.replace(/_/g, " "),
      href: "/mistakes",
      examId: m.examId,
      body: `${stem} ${m.userAnswer} ${m.notes} ${m.category}`,
    });
  }
  for (const n of notes) {
    docs.push({
      id: `note:${n.id}`,
      kind: "note",
      title: n.title || "Untitled note",
      snippet: n.body.slice(0, 120),
      href: `/notes/${n.id}`,
      examId: n.examId,
      body: `${n.title} ${n.body}`,
    });
  }
  for (const f of formulas) {
    docs.push({
      id: `f:${f.id}`,
      kind: "formula",
      title: f.name,
      snippet: f.formula,
      href: "/formulas",
      examId: f.examIds[0] ?? null,
      body: `${f.name} ${f.formula} ${f.meaning} ${f.whenToUse} ${f.commonMistake} ${f.category}`,
    });
  }
  for (const c of concepts) {
    docs.push({
      id: `c:${c.id}`,
      kind: "concept",
      title: c.name,
      snippet: c.summary.slice(0, 140),
      href: `/concepts/${c.id}`,
      examId: c.examIds[0] ?? null,
      body: `${c.name} ${c.aliases.join(" ")} ${c.summary}`,
    });
  }
  for (const m of mocks) {
    docs.push({
      id: `mock:${m.id}`,
      kind: "mock",
      title: m.name,
      snippet: `${m.kind} · ${m.questionIds.length} questions`,
      href: `/mocks`,
      examId: m.examId,
      body: m.name,
    });
  }

  const mini = new MiniSearch<(typeof docs)[number]>({
    fields: ["title", "body", "snippet"],
    storeFields: ["kind", "title", "snippet", "href", "examId"],
    searchOptions: { prefix: true, fuzzy: 0.15 },
  });
  mini.addAll(docs);
  const textHits = mini.search(q).slice(0, 24);
  const results: SearchHit[] = textHits.map((h) => ({
    id: String(h.id),
    kind: h.kind as SearchHit["kind"],
    title: h.title,
    snippet: h.snippet,
    href: h.href,
    examId: h.examId,
  }));

  try {
    const pages = await searchPages(q, 8);
    for (const p of pages) {
      results.push({
        id: `page:${p.bookId}:${p.page}`,
        kind: "page",
        title: `${p.bookName} · p. ${p.page}`,
        snippet: p.text,
        href: `/read/${p.bookId}?page=${p.page}`,
        examId: books.find((b) => b.id === p.bookId)?.examId ?? null,
      });
    }
  } catch {
    // Page scan is best-effort.
  }

  return results.slice(0, 30);
}
