import { average, clamp } from "@/lib/utils";
import type {
  Attempt,
  Exam,
  Mistake,
  MockResult,
  PriorityItem,
  Question,
  ReadinessBreakdown,
  ReadinessWeights,
  RecallResult,
  RevisionItem,
  SpeedPattern,
  Topic,
  TopicAnalytics,
  TopicStatus,
} from "./types";
import { DEFAULT_WEIGHTS } from "./types";

export const STATUS_BASE: Record<TopicStatus, number> = {
  not_started: 0,
  reading: 12,
  read: 28,
  practiced: 48,
  revised: 64,
  strong: 80,
  mastered: 92,
};

const HALF_LIFE_DAYS = 18;

export function decayRetention(lastRevisedAt: number | null, now = Date.now()): number {
  if (!lastRevisedAt) return 40;
  const days = (now - lastRevisedAt) / 86400000;
  const retain = Math.pow(0.5, days / HALF_LIFE_DAYS);
  return clamp(retain * 100, 8, 100);
}

export function topicKnowledge(input: {
  topic: Topic;
  attempts: Attempt[];
  mistakes: Mistake[];
  revisions: RevisionItem[];
  now?: number;
}): number {
  const { topic, attempts, mistakes, revisions } = input;
  const now = input.now ?? Date.now();
  const status = STATUS_BASE[topic.status];

  const recent = attempts.slice().sort((a, b) => b.createdAt - a.createdAt).slice(0, 25);
  const accuracy = recent.length
    ? (recent.filter((a) => a.correct).length / recent.length) * 100
    : null;

  const recencyMistakes = mistakes.filter((m) => now - m.createdAt < 21 * 86400000).length;
  const mistakePenalty = clamp(recencyMistakes * 7, 0, 55);

  const topicRevs = revisions
    .filter((r) => r.topicId === topic.id || (r.kind === "topic" && r.refId === topic.id))
    .sort((a, b) => (b.lastReviewedAt ?? 0) - (a.lastReviewedAt ?? 0));
  const lastRev = topicRevs[0];
  let recall = 55;
  if (lastRev?.lastResult === "knew") recall = 92;
  else if (lastRev?.lastResult === "partial") recall = 62;
  else if (lastRev?.lastResult === "forgot") recall = 28;
  const retention = lastRev?.lastReviewedAt
    ? decayRetention(lastRev.lastReviewedAt, now) * (recall / 100) * (100 / 70)
    : topic.lastRevisedAt
      ? decayRetention(topic.lastRevisedAt, now)
      : topic.lastStudiedAt
        ? decayRetention(topic.lastStudiedAt, now) * 0.7
        : 35;

  if (accuracy === null && !topicRevs.length && topic.status === "not_started") return 0;
  if (accuracy === null) {
    return clamp(status * 0.7 + retention * 0.3 - mistakePenalty * 0.15, 0, status);
  }

  const raw =
    status * 0.28 + accuracy * 0.34 + clamp(retention, 0, 100) * 0.22 + (100 - mistakePenalty) * 0.16;
  return clamp(Math.round(raw), 0, 100);
}

export function advanceStatus(current: TopicStatus, event: "read" | "practice" | "revise"): TopicStatus {
  if (event === "read") {
    if (current === "not_started" || current === "reading") return "read";
    return current;
  }
  if (event === "practice") {
    if (STATUS_BASE[current] < STATUS_BASE.practiced) return "practiced";
    return current;
  }
  if (current === "not_started" || current === "reading" || current === "read" || current === "practiced") {
    return "revised";
  }
  return current;
}

export function maybePromote(status: TopicStatus, knowledge: number, accuracy: number | null): TopicStatus {
  if (accuracy !== null && accuracy >= 90 && knowledge >= 88) return "mastered";
  if (accuracy !== null && accuracy >= 80 && knowledge >= 75 && STATUS_BASE[status] >= STATUS_BASE.revised) {
    return "strong";
  }
  return status;
}

export function classifySpeed(accuracy: number, avgTimeMs: number, targetMs: number): SpeedPattern {
  if (!Number.isFinite(accuracy) || !Number.isFinite(avgTimeMs) || targetMs <= 0) return "neutral";
  const slow = avgTimeMs > targetMs * 1.25;
  const fast = avgTimeMs < targetMs * 0.75;
  const highAcc = accuracy >= 80;
  const lowAcc = accuracy < 60;
  if (highAcc && slow) return "speed";
  if (lowAcc && fast) return "concept";
  if (lowAcc && slow) return "major";
  if (highAcc && fast) return "strong";
  return "neutral";
}

export const PATTERN_COPY: Record<SpeedPattern, string> = {
  speed: "High accuracy, slow pace — speed problem",
  concept: "Low accuracy, fast pace — concept problem",
  major: "Low accuracy, slow pace — major weakness",
  strong: "High accuracy, fast pace — strong area",
  neutral: "No dominant pattern yet",
};

export function topicAnalytics(
  topics: Topic[],
  questions: Question[],
  attempts: Attempt[],
  targetMsByExam: Record<string, number>,
  defaultTarget = 120000,
): TopicAnalytics[] {
  const qByTopic = new Map<string, Question[]>();
  for (const q of questions) {
    if (!q.topicId) continue;
    const list = qByTopic.get(q.topicId) ?? [];
    list.push(q);
    qByTopic.set(q.topicId, list);
  }
  const attemptsByQ = new Map<string, Attempt[]>();
  for (const a of attempts) {
    const list = attemptsByQ.get(a.questionId) ?? [];
    list.push(a);
    attemptsByQ.set(a.questionId, list);
  }

  return topics
    .map((topic) => {
      const tq = qByTopic.get(topic.id) ?? [];
      const atts: Attempt[] = [];
      const hard: Attempt[] = [];
      const easy: Attempt[] = [];
      for (const q of tq) {
        const qa = attemptsByQ.get(q.id) ?? [];
        atts.push(...qa);
        if (q.difficulty === "hard") hard.push(...qa);
        if (q.difficulty === "easy") easy.push(...qa);
      }
      const questionsN = atts.length;
      const correct = atts.filter((a) => a.correct).length;
      const accuracy = questionsN ? (correct / questionsN) * 100 : 0;
      const avgTimeMs = questionsN ? average(atts.map((a) => a.timeMs)) : 0;
      const hardAccuracy = hard.length ? (hard.filter((a) => a.correct).length / hard.length) * 100 : null;
      const easyAccuracy = easy.length ? (easy.filter((a) => a.correct).length / easy.length) * 100 : null;
      const target = (topic.examId && targetMsByExam[topic.examId]) || defaultTarget;
      return {
        topicId: topic.id,
        title: topic.title,
        examId: topic.examId,
        questions: questionsN,
        correct,
        accuracy,
        avgTimeMs,
        hardAccuracy,
        easyAccuracy,
        pattern: questionsN >= 4 ? classifySpeed(accuracy, avgTimeMs, target) : "neutral",
      };
    })
    .filter((t) => t.questions > 0)
    .sort((a, b) => a.accuracy - b.accuracy);
}

export function examReadiness(input: {
  exam: Exam;
  topics: Topic[];
  knowledgeByTopic: Record<string, number>;
  attempts: Attempt[];
  questions: Question[];
  revisions: RevisionItem[];
  mockResults: MockResult[];
  weights?: ReadinessWeights;
  targetMs?: number;
  now?: number;
}): ReadinessBreakdown {
  const weights = input.weights ?? DEFAULT_WEIGHTS;
  const now = input.now ?? Date.now();
  const examTopics = input.topics.filter((t) => t.examId === input.exam.id);
  const examQuestionIds = new Set(
    input.questions.filter((q) => q.examId === input.exam.id).map((q) => q.id),
  );
  const examAttempts = input.attempts.filter((a) => examQuestionIds.has(a.questionId));
  const examRevs = input.revisions.filter((r) => r.examId === input.exam.id);

  const knowVals = examTopics.map((t) => input.knowledgeByTopic[t.id] ?? 0);
  const knowledge = examTopics.length ? average(knowVals) : null;

  const recentAtt = examAttempts.slice().sort((a, b) => b.createdAt - a.createdAt).slice(0, 80);
  const accuracy = recentAtt.length
    ? (recentAtt.filter((a) => a.correct).length / recentAtt.length) * 100
    : null;

  const timed = recentAtt.filter((a) => a.timeMs > 0);
  const target = input.targetMs ?? 120000;
  const speed = timed.length
    ? (timed.filter((a) => a.timeMs <= target).length / timed.length) * 100
    : null;

  const due = examRevs.filter((r) => r.dueAt <= now).length;
  const reviewed = examRevs.filter((r) => r.lastReviewedAt && now - r.lastReviewedAt < 14 * 86400000);
  const knew = reviewed.filter((r) => r.lastResult === "knew").length;
  const retention =
    examRevs.length === 0
      ? knowledge === null
        ? null
        : clamp((knowledge ?? 0) * 0.6, 0, 100)
      : clamp(
          (1 - due / Math.max(examRevs.length, 1)) * 55 +
            (reviewed.length ? (knew / reviewed.length) * 45 : 20),
          0,
          100,
        );

  const examMocks = input.mockResults
    .filter((m) => {
      return true;
    })
    .slice()
    .sort((a, b) => b.submittedAt - a.submittedAt)
    .slice(0, 5);
  const mock = examMocks.length ? average(examMocks.map((m) => (m.maxScore ? (m.score / m.maxScore) * 100 : m.accuracy))) : null;

  const topicsWeak = examTopics.filter((t) => (input.knowledgeByTopic[t.id] ?? 0) < 50).length;
  const weak =
    examTopics.length === 0 ? null : (1 - topicsWeak / examTopics.length) * 100;

  const topicsCompleted = examTopics.filter(
    (t) => STATUS_BASE[t.status] >= STATUS_BASE.practiced,
  ).length;

  const parts = [
    [knowledge, weights.knowledge],
    [accuracy, weights.accuracy],
    [speed, weights.speed],
    [retention, weights.retention],
    [mock, weights.mock],
    [weak, weights.weak],
  ] as const;
  const available = parts.filter((p) => p[0] !== null) as [number, number][];
  const evidence =
    (knowledge !== null ? 1 : 0) +
    (accuracy !== null ? 1 : 0) +
    (mock !== null ? 1 : 0) +
    (examRevs.length ? 1 : 0);
  let overall: number | null = null;
  if (available.length && evidence >= 1 && (examAttempts.length >= 3 || examMocks.length || topicsCompleted)) {
    const wsum = available.reduce((s, p) => s + p[1], 0) || 1;
    overall = available.reduce((s, p) => s + p[0] * p[1], 0) / wsum;
  }

  return {
    examId: input.exam.id,
    overall: overall === null ? null : clamp(Math.round(overall), 0, 100),
    knowledge: knowledge === null ? null : Math.round(knowledge),
    accuracy: accuracy === null ? null : Math.round(accuracy),
    speed: speed === null ? null : Math.round(speed),
    retention: retention === null ? null : Math.round(retention),
    mock: mock === null ? null : Math.round(mock),
    weak: weak === null ? null : Math.round(weak),
    topicsTotal: examTopics.length,
    topicsCompleted,
    topicsWeak,
    revisionDue: due,
  };
}

export function nextInterval(item: RevisionItem, result: RecallResult): { intervalDays: number; ease: number; dueAt: number } {
  let { intervalDays, ease } = item;
  if (result === "forgot") {
    intervalDays = 1;
    ease = Math.max(1.3, ease - 0.2);
  } else if (result === "partial") {
    intervalDays = Math.max(1, Math.round(intervalDays * 1.2));
    ease = Math.max(1.3, ease - 0.05);
  } else {
    ease = Math.min(2.8, ease + 0.08);
    intervalDays = item.repetitions === 0 ? 1 : item.repetitions === 1 ? 3 : Math.round(intervalDays * ease);
  }
  return {
    intervalDays,
    ease,
    dueAt: Date.now() + intervalDays * 86400000,
  };
}

export function revisionBucket(dueAt: number, now = Date.now()): "today" | "soon" | "later" {
  const days = (dueAt - now) / 86400000;
  if (days <= 0.5) return "today";
  if (days <= 3) return "soon";
  return "later";
}

export function whyLosingMarks(mistakes: Mistake[]): { category: string; count: number }[] {
  const map = new Map<string, number>();
  for (const m of mistakes) {
    map.set(m.category, (map.get(m.category) ?? 0) + 1);
  }
  return [...map.entries()]
    .map(([category, count]) => ({ category, count }))
    .sort((a, b) => b.count - a.count);
}

export function buildPriorities(input: {
  exams: Exam[];
  topics: Topic[];
  knowledgeByTopic: Record<string, number>;
  mistakes: Mistake[];
  revisions: RevisionItem[];
  questions: Question[];
  attempts: Attempt[];
  booksCount: number;
  now?: number;
}): PriorityItem[] {
  const now = input.now ?? Date.now();
  const items: (PriorityItem & { score: number })[] = [];
  const activeExams = input.exams.filter((e) => e.active);
  const examName = (id: string | null) => activeExams.find((e) => e.id === id)?.name ?? null;

  if (activeExams.length === 0) {
    items.push({
      id: "setup-exam",
      title: "Add your first exam",
      reason: "CFA, CAT, GRE, or anything you are preparing for.",
      href: "/settings",
      examName: null,
      urgency: "now",
      score: 1000,
    });
  }

  if (input.booksCount === 0) {
    items.push({
      id: "upload-book",
      title: "Upload your first book",
      reason: "The OS is built around your own PDFs — start the library.",
      href: "/library",
      examName: null,
      urgency: "now",
      score: 900,
    });
  }

  if (input.attempts.length === 0 && input.questions.length > 0) {
    items.push({
      id: "first-practice",
      title: "Answer a short practice set",
      reason: "Accuracy data is what turns reading into readiness.",
      href: "/practice",
      examName: null,
      urgency: "today",
      score: 850,
    });
  }

  for (const rev of input.revisions) {
    if (rev.dueAt > now) continue;
    const overdueDays = (now - rev.dueAt) / 86400000;
    items.push({
      id: `rev-${rev.id}`,
      title: rev.prompt.length > 72 ? `${rev.prompt.slice(0, 69)}…` : rev.prompt,
      reason: overdueDays > 1 ? `Revision overdue by ${Math.floor(overdueDays)}d` : "Revision due today",
      href: "/revision",
      examName: examName(rev.examId),
      urgency: "now",
      score: 700 + Math.min(80, overdueDays * 8) + (activeExams.find((e) => e.id === rev.examId)?.priority ?? 3) * 6,
    });
  }

  const recentMistakes = input.mistakes.filter((m) => now - m.createdAt < 14 * 86400000);
  const byTopic = new Map<string, number>();
  for (const m of recentMistakes) {
    if (!m.topicId) continue;
    byTopic.set(m.topicId, (byTopic.get(m.topicId) ?? 0) + 1);
  }
  for (const [topicId, count] of byTopic) {
    const topic = input.topics.find((t) => t.id === topicId);
    if (!topic) continue;
    items.push({
      id: `weak-${topicId}`,
      title: `${topic.title} — practice`,
      reason: `${count} recent mistake${count === 1 ? "" : "s"} on this topic`,
      href: `/practice/run?mode=topic&topicId=${topicId}`,
      examName: examName(topic.examId),
      urgency: count >= 4 ? "now" : "today",
      score: 520 + count * 18 + (activeExams.find((e) => e.id === topic.examId)?.priority ?? 3) * 8,
    });
  }

  for (const topic of input.topics) {
    const k = input.knowledgeByTopic[topic.id] ?? 0;
    if (k > 0 && k < 45 && topic.status !== "not_started") {
      items.push({
        id: `lowk-${topic.id}`,
        title: `Rebuild ${topic.title}`,
        reason: `Knowledge score ${Math.round(k)}% — below a safe floor`,
        href: `/practice/run?mode=topic&topicId=${topic.id}`,
        examName: examName(topic.examId),
        urgency: "today",
        score: 400 + (45 - k) + topic.importance * 10,
      });
    }
  }

  for (const exam of activeExams) {
    const unread = input.topics.find(
      (t) => t.examId === exam.id && (t.status === "not_started" || t.status === "reading"),
    );
    if (unread) {
      const days = exam.date ? Math.max(0, (exam.date - now) / 86400000) : 180;
      items.push({
        id: `read-${unread.id}`,
        title: `Read ${unread.title}`,
        reason: "Next unread topic in this exam",
        href: unread.bookId ? `/library/${unread.bookId}` : "/library",
        examName: exam.name,
        urgency: days < 30 ? "today" : "soon",
        score: 260 + exam.priority * 12 + (days < 60 ? 40 : 0),
      });
    }
  }

  const seen = new Set<string>();
  return items
    .sort((a, b) => b.score - a.score)
    .filter((p) => {
      const key = p.title;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .slice(0, 5)
    .map(({ score: _s, ...rest }) => rest);
}

export interface MockInsightBlock {
  wentWrong: string[];
  wentWell: string[];
  fixNext: string[];
}

export function analyzeMock(input: {
  result: MockResult;
  questions: Question[];
  mistakes: Mistake[];
  timeLimitMin: number;
  sections: { name: string; questionIds: string[] }[];
}): MockInsightBlock {
  const { result, questions, mistakes, timeLimitMin, sections } = input;
  const qMap = new Map(questions.map((q) => [q.id, q]));
  const answered = result.answers.filter((a) => !a.skipped && a.answer);
  const unattempted = result.answers.filter((a) => a.skipped || !a.answer);
  const byCat = whyLosingMarks(mistakes);
  const wentWrong: string[] = [];
  const wentWell: string[] = [];
  const fixNext: string[] = [];

  const usedMs = result.answers.reduce((s, a) => s + a.timeMs, 0);
  const allotted = timeLimitMin * 60000;
  const leftover = allotted - usedMs;

  if (unattempted.length && leftover > 90_000) {
    wentWrong.push(
      `Left ${unattempted.length} question${unattempted.length === 1 ? "" : "s"} unattempted with ${Math.round(leftover / 60000)} min remaining — a selection issue, not a time shortage.`,
    );
    fixNext.push("Decide skip rules before the next mock: cap time per item and move on.");
  } else if (unattempted.length && leftover <= 0) {
    wentWrong.push(
      `Time expired with ${unattempted.length} unattempted. Speed or over-investment in hard items is the constraint.`,
    );
    fixNext.push("Run a timed sectional focusing on the slowest section.");
  }

  if (byCat[0] && byCat[0].count >= 2) {
    const label = byCat[0].category.replace(/_/g, " ");
    wentWrong.push(
      `${byCat[0].count} recorded mistakes classified as ${label} — that is the dominant leak.`,
    );
    if (byCat[0].category === "careless" || byCat[0].category === "misread") {
      fixNext.push("Add a 5-second stem re-read before marking any option on the next timed set.");
    } else if (byCat[0].category === "concept_gap" || byCat[0].category === "wrong_approach") {
      fixNext.push("Revisit the underlying topic with recall, then 10 mixed questions — do not re-read notes only.");
    } else if (byCat[0].category === "time_pressure") {
      fixNext.push("Practice the same difficulty with a tighter per-question cap.");
    }
  }

  const sectionStats = sections.map((s) => {
    const ids = new Set(s.questionIds);
    const rows = result.answers.filter((a) => ids.has(a.questionId));
    const att = rows.filter((a) => a.answer && !a.skipped);
    const correct = att.filter((a) => {
      const q = qMap.get(a.questionId);
      return q ? a.answer === q.correctAnswer : false;
    }).length;
    const acc = att.length ? (correct / att.length) * 100 : 0;
    return { name: s.name, acc, n: att.length, total: rows.length };
  });
  if (sectionStats.length >= 2) {
    const best = [...sectionStats].sort((a, b) => b.acc - a.acc)[0];
    const worst = [...sectionStats].sort((a, b) => a.acc - b.acc)[0];
    if (best && best.n) wentWell.push(`${best.name} led with ${Math.round(best.acc)}% accuracy on ${best.n} attempts.`);
    if (worst && best && worst.name !== best.name && worst.n) {
      wentWrong.push(`${worst.name} lagged at ${Math.round(worst.acc)}% accuracy.`);
      fixNext.push(`Next session: sectional mock on ${worst.name} only.`);
    }
  }

  const easyWrong = answered.filter((a) => {
    const q = qMap.get(a.questionId);
    return q?.difficulty === "easy" && a.answer !== q.correctAnswer;
  }).length;
  if (easyWrong >= 2) {
    wentWrong.push(`${easyWrong} easy items missed — those are recoverable marks.`);
  }

  const hardRight = answered.filter((a) => {
    const q = qMap.get(a.questionId);
    return q?.difficulty === "hard" && a.answer === q.correctAnswer;
  }).length;
  if (hardRight >= 2) {
    wentWell.push(`Converted ${hardRight} hard items. That is real skill, not luck on easy marks.`);
  }

  if (result.accuracy >= 80 && answered.length) {
    wentWell.push(`Accuracy ${Math.round(result.accuracy)}% on attempted items.`);
  }
  if (result.attemptRate >= 85) {
    wentWell.push(`Attempt rate ${Math.round(result.attemptRate)}% — coverage was not the problem.`);
  }

  const topicMiss = new Map<string, number>();
  for (const a of answered) {
    const q = qMap.get(a.questionId);
    if (!q?.topicId) continue;
    if (a.answer !== q.correctAnswer) topicMiss.set(q.topicId, (topicMiss.get(q.topicId) ?? 0) + 1);
  }
  const topMiss = [...topicMiss.entries()].sort((a, b) => b[1] - a[1])[0];
  if (topMiss) {
    const q = questions.find((x) => x.topicId === topMiss[0]);
    const label = q?.tags[0] ?? "the weakest topic in this mock";
    fixNext.push(`Drill ${label} tomorrow before opening a new mock.`);
  }

  return {
    wentWrong: wentWrong.slice(0, 5),
    wentWell: wentWell.slice(0, 5),
    fixNext: [...new Set(fixNext)].slice(0, 4),
  };
}
