import { nid } from "@/lib/utils";
import { requireDb } from "./db";
import { advanceStatus, maybePromote, nextInterval, topicKnowledge } from "./engines";
import type {
  AppSettings,
  Attempt,
  Book,
  Bookmark,
  Chapter,
  Concept,
  Exam,
  Formula,
  Highlight,
  Mistake,
  MistakeCategory,
  MockResult,
  MockTest,
  Note,
  NoteType,
  Question,
  RecallResult,
  RevisionItem,
  StudySession,
  Topic,
  TopicStatus,
} from "./types";
import { DEFAULT_WEIGHTS } from "./types";

export async function getSettings(): Promise<AppSettings> {
  const db = requireDb();
  const row = await db.settings.get("settings");
  if (row) return row;
  const fresh: AppSettings = {
    id: "settings",
    theme: "system",
    displayName: "",
    onboardingComplete: false,
    seedVersion: 0,
    targetTimes: {
      "exam-cfa": 150000,
      "exam-cat": 90000,
      "exam-gre": 120000,
    },
    readinessWeights: { ...DEFAULT_WEIGHTS },
    includeStarterContent: true,
  };
  await db.settings.put(fresh);
  return fresh;
}

export async function patchSettings(patch: Partial<AppSettings>) {
  const cur = await getSettings();
  await requireDb().settings.put({ ...cur, ...patch, id: "settings" });
}

export async function createExam(input: { name: string; date?: number | null; priority?: number; targetScore?: number | null }) {
  const exam: Exam = {
    id: nid(),
    name: input.name.trim(),
    date: input.date ?? null,
    priority: input.priority ?? 3,
    targetScore: input.targetScore ?? null,
    active: true,
    createdAt: Date.now(),
  };
  await requireDb().exams.add(exam);
  return exam;
}

export async function updateExam(id: string, patch: Partial<Exam>) {
  await requireDb().exams.update(id, patch);
}

export async function createTopic(input: Partial<Topic> & { title: string }): Promise<Topic> {
  const topic: Topic = {
    id: nid(),
    chapterId: input.chapterId ?? null,
    bookId: input.bookId ?? null,
    examId: input.examId ?? null,
    subjectId: input.subjectId ?? null,
    title: input.title,
    pageStart: input.pageStart ?? null,
    pageEnd: input.pageEnd ?? null,
    order: input.order ?? 0,
    status: input.status ?? "not_started",
    importance: input.importance ?? 3,
    lastStudiedAt: null,
    lastRevisedAt: null,
    nextRevisionAt: null,
    createdAt: Date.now(),
  };
  await requireDb().topics.add(topic);
  return topic;
}

export async function setTopicStatus(id: string, status: TopicStatus) {
  await requireDb().topics.update(id, { status, lastStudiedAt: Date.now() });
}

export async function markTopicEvent(topicId: string, event: "read" | "practice" | "revise") {
  const db = requireDb();
  const topic = await db.topics.get(topicId);
  if (!topic) return;
  const next = advanceStatus(topic.status, event);
  const patch: Partial<Topic> = {
    status: next,
    lastStudiedAt: Date.now(),
  };
  if (event === "revise") {
    patch.lastRevisedAt = Date.now();
    patch.nextRevisionAt = Date.now() + 2 * 86400000;
  }
  await db.topics.update(topicId, patch);
}

export async function saveQuestion(q: Question) {
  await requireDb().questions.put(q);
}

export async function createQuestion(input: Omit<Question, "id" | "createdAt">): Promise<Question> {
  const q: Question = { ...input, id: nid(), createdAt: Date.now() };
  await requireDb().questions.add(q);
  return q;
}

export async function recordAttempt(input: {
  question: Question;
  answer: string;
  correct: boolean;
  confidence: number | null;
  timeMs: number;
  sessionId?: string | null;
  mockResultId?: string | null;
  mistakeCategory?: MistakeCategory | null;
  mistakeNotes?: string;
}): Promise<{ attempt: Attempt; mistake: Mistake | null }> {
  const db = requireDb();
  const attempt: Attempt = {
    id: nid(),
    questionId: input.question.id,
    sessionId: input.sessionId ?? null,
    mockResultId: input.mockResultId ?? null,
    answer: input.answer,
    correct: input.correct,
    confidence: input.confidence,
    timeMs: input.timeMs,
    createdAt: Date.now(),
  };
  await db.attempts.add(attempt);
  let mistake: Mistake | null = null;
  if (!input.correct) {
    mistake = {
      id: nid(),
      questionId: input.question.id,
      attemptId: attempt.id,
      userAnswer: input.answer,
      correctAnswer: input.question.correctAnswer,
      category: input.mistakeCategory ?? "other",
      topicId: input.question.topicId,
      examId: input.question.examId,
      difficulty: input.question.difficulty,
      timeMs: input.timeMs,
      notes: input.mistakeNotes ?? "",
      createdAt: Date.now(),
    };
    await db.mistakes.add(mistake);
  }
  if (input.question.topicId) {
    await markTopicEvent(input.question.topicId, "practice");
    const topic = await db.topics.get(input.question.topicId);
    if (topic) {
      const atts = await db.attempts
        .filter((a) => {
          return true;
        })
        .toArray();
      const qids = new Set(
        (await db.questions.where("topicId").equals(input.question.topicId).toArray()).map((q) => q.id),
      );
      const topicAtts = atts.filter((a) => qids.has(a.questionId));
      const mistakes = await db.mistakes.where("topicId").equals(input.question.topicId).toArray();
      const revs = await db.revisionItems.where("topicId").equals(input.question.topicId).toArray();
      const k = topicKnowledge({ topic, attempts: topicAtts, mistakes, revisions: revs });
      const acc = topicAtts.length
        ? (topicAtts.filter((a) => a.correct).length / topicAtts.length) * 100
        : null;
      const promoted = maybePromote(topic.status, k, acc);
      if (promoted !== topic.status) await db.topics.update(topic.id, { status: promoted });
    }
  }
  if (input.sessionId) {
    const s = await db.studySessions.get(input.sessionId);
    if (s) {
      await db.studySessions.update(s.id, {
        questionsSolved: s.questionsSolved + 1,
        correctCount: s.correctCount + (input.correct ? 1 : 0),
      });
    }
  }
  return { attempt, mistake };
}

export async function classifyMistake(id: string, category: MistakeCategory, notes?: string) {
  await requireDb().mistakes.update(id, { category, notes: notes ?? "" });
}

export async function addRevision(input: {
  kind: RevisionItem["kind"];
  refId: string;
  prompt: string;
  answer: string;
  examId?: string | null;
  topicId?: string | null;
}): Promise<RevisionItem> {
  const item: RevisionItem = {
    id: nid(),
    kind: input.kind,
    refId: input.refId,
    examId: input.examId ?? null,
    topicId: input.topicId ?? null,
    prompt: input.prompt,
    answer: input.answer,
    dueAt: Date.now(),
    intervalDays: 1,
    ease: 2.5,
    repetitions: 0,
    lastResult: null,
    createdAt: Date.now(),
    lastReviewedAt: null,
  };
  await requireDb().revisionItems.add(item);
  return item;
}

export async function reviewRevision(id: string, result: RecallResult) {
  const db = requireDb();
  const item = await db.revisionItems.get(id);
  if (!item) return;
  const next = nextInterval(item, result);
  await db.revisionItems.update(id, {
    ...next,
    lastResult: result,
    lastReviewedAt: Date.now(),
    repetitions: item.repetitions + 1,
  });
  if (item.topicId) await markTopicEvent(item.topicId, "revise");
}

export async function saveNote(input: {
  id?: string;
  type?: NoteType;
  title: string;
  body: string;
  examId?: string | null;
  bookId?: string | null;
  chapterId?: string | null;
  topicId?: string | null;
  questionId?: string | null;
  conceptId?: string | null;
}): Promise<Note> {
  const db = requireDb();
  const now = Date.now();
  if (input.id) {
    const existing = await db.notes.get(input.id);
    if (existing) {
      const next = {
        ...existing,
        title: input.title,
        body: input.body,
        type: input.type ?? existing.type,
        examId: input.examId ?? existing.examId,
        bookId: input.bookId ?? existing.bookId,
        chapterId: input.chapterId ?? existing.chapterId,
        topicId: input.topicId ?? existing.topicId,
        questionId: input.questionId ?? existing.questionId,
        conceptId: input.conceptId ?? existing.conceptId,
        updatedAt: now,
      };
      await db.notes.put(next);
      return next;
    }
  }
  const note: Note = {
    id: input.id ?? nid(),
    type: input.type ?? "text",
    title: input.title,
    body: input.body,
    examId: input.examId ?? null,
    bookId: input.bookId ?? null,
    chapterId: input.chapterId ?? null,
    topicId: input.topicId ?? null,
    questionId: input.questionId ?? null,
    conceptId: input.conceptId ?? null,
    createdAt: now,
    updatedAt: now,
  };
  await db.notes.add(note);
  return note;
}

export async function saveFormula(f: Formula) {
  await requireDb().formulas.put(f);
}

export async function createFormula(input: Omit<Formula, "id" | "createdAt">): Promise<Formula> {
  const f: Formula = { ...input, id: nid(), createdAt: Date.now() };
  await requireDb().formulas.add(f);
  return f;
}

export async function startSession(input: {
  examId?: string | null;
  topicId?: string | null;
  bookId?: string | null;
  title: string;
  plannedMin: number;
}): Promise<StudySession> {
  const s: StudySession = {
    id: nid(),
    examId: input.examId ?? null,
    topicId: input.topicId ?? null,
    bookId: input.bookId ?? null,
    title: input.title,
    startedAt: Date.now(),
    endedAt: null,
    plannedMin: input.plannedMin,
    questionsSolved: 0,
    correctCount: 0,
    notesCreated: 0,
    revisionsCreated: 0,
  };
  await requireDb().studySessions.add(s);
  return s;
}

export async function endSession(id: string) {
  await requireDb().studySessions.update(id, { endedAt: Date.now() });
}

export async function saveMock(m: MockTest) {
  await requireDb().mocks.put(m);
}

export async function createMock(input: Omit<MockTest, "id" | "createdAt">): Promise<MockTest> {
  const m: MockTest = { ...input, id: nid(), createdAt: Date.now() };
  await requireDb().mocks.add(m);
  return m;
}

export async function saveMockResult(r: MockResult) {
  await requireDb().mockResults.put(r);
}

export async function addHighlight(h: Omit<Highlight, "id" | "createdAt">): Promise<Highlight> {
  const row: Highlight = { ...h, id: nid(), createdAt: Date.now() };
  await requireDb().highlights.add(row);
  return row;
}

export async function addBookmark(b: Omit<Bookmark, "id" | "createdAt">): Promise<Bookmark> {
  const row: Bookmark = { ...b, id: nid(), createdAt: Date.now() };
  await requireDb().bookmarks.add(row);
  return row;
}

export async function saveChapters(bookId: string, chapters: Chapter[]) {
  const db = requireDb();
  await db.transaction("rw", db.chapters, async () => {
    await db.chapters.where("bookId").equals(bookId).delete();
    if (chapters.length) await db.chapters.bulkAdd(chapters);
  });
}

export async function saveTopicsForBook(bookId: string, topics: Topic[]) {
  const db = requireDb();
  const existing = await db.topics.where("bookId").equals(bookId).toArray();
  const keep = new Set(topics.map((t) => t.id));
  await db.transaction("rw", db.topics, async () => {
    for (const e of existing) {
      if (!keep.has(e.id)) await db.topics.delete(e.id);
    }
    for (const t of topics) await db.topics.put(t);
  });
}

export async function updateBook(id: string, patch: Partial<Book>) {
  await requireDb().books.update(id, patch);
}

export async function deleteBook(id: string) {
  const db = requireDb();
  await db.transaction(
    "rw",
    [
      db.books,
      db.bookFiles,
      db.chapters,
      db.topics,
      db.pageTexts,
      db.highlights,
      db.bookmarks,
      db.notes,
    ],
    async () => {
      await db.books.delete(id);
      await db.bookFiles.delete(id);
      await db.chapters.where("bookId").equals(id).delete();
      await db.topics.where("bookId").equals(id).delete();
      await db.pageTexts.where("bookId").equals(id).delete();
      await db.highlights.where("bookId").equals(id).delete();
      await db.bookmarks.where("bookId").equals(id).delete();
    },
  );
}

export async function deleteQuestion(id: string) {
  await requireDb().questions.delete(id);
}

export async function deleteNote(id: string) {
  await requireDb().notes.delete(id);
}

export async function deleteMistake(id: string) {
  await requireDb().mistakes.delete(id);
}

export async function upsertConcept(c: Concept) {
  await requireDb().concepts.put(c);
}

export async function createConcept(name: string, extra?: Partial<Concept>): Promise<Concept> {
  const c: Concept = {
    id: nid(),
    name,
    aliases: extra?.aliases ?? [],
    examIds: extra?.examIds ?? [],
    topicIds: extra?.topicIds ?? [],
    summary: extra?.summary ?? "",
    createdAt: Date.now(),
  };
  await requireDb().concepts.add(c);
  return c;
}
