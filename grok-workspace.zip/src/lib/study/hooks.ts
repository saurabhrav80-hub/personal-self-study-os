import { useLiveQuery } from "dexie-react-hooks";
import { useMemo } from "react";
import { getDb } from "./db";
import { examReadiness, topicKnowledge } from "./engines";
import { getSettings } from "./repo";
import type { ReadinessBreakdown } from "./types";

export function useExams() {
  return (
    useLiveQuery(async () => {
      const db = getDb();
      if (!db) return [];
      const all = await db.exams.toArray();
      return all.filter((e) => e.active).sort((a, b) => b.priority - a.priority || a.name.localeCompare(b.name));
    }, []) ?? []
  );
}

export function useAllExams() {
  return (
    useLiveQuery(async () => {
      const db = getDb();
      if (!db) return [];
      return db.exams.toArray();
    }, []) ?? []
  );
}

export function useSubjects(examId?: string) {
  return (
    useLiveQuery(async () => {
      const db = getDb();
      if (!db) return [];
      const all = await db.subjects.toArray();
      return examId ? all.filter((s) => s.examId === examId) : all;
    }, [examId]) ?? []
  );
}

export function useBooks() {
  return (
    useLiveQuery(async () => {
      const db = getDb();
      if (!db) return [];
      const all = await db.books.toArray();
      return all.sort((a, b) => (b.lastOpenedAt ?? b.createdAt) - (a.lastOpenedAt ?? a.createdAt));
    }, []) ?? []
  );
}

export function useBook(id: string | undefined) {
  return useLiveQuery(async () => {
    if (!id) return undefined;
    return getDb()?.books.get(id);
  }, [id]);
}

export function useChapters(bookId: string | undefined) {
  return (
    useLiveQuery(async () => {
      if (!bookId) return [];
      const db = getDb();
      if (!db) return [];
      return db.chapters.where("bookId").equals(bookId).sortBy("order");
    }, [bookId]) ?? []
  );
}

export function useTopics(filter?: { bookId?: string; examId?: string }) {
  return (
    useLiveQuery(async () => {
      const db = getDb();
      if (!db) return [];
      let rows = await db.topics.toArray();
      if (filter?.bookId) rows = rows.filter((t) => t.bookId === filter.bookId);
      if (filter?.examId) rows = rows.filter((t) => t.examId === filter.examId);
      return rows.sort((a, b) => a.order - b.order || a.title.localeCompare(b.title));
    }, [filter?.bookId, filter?.examId]) ?? []
  );
}

export function useQuestions() {
  return (
    useLiveQuery(async () => {
      const db = getDb();
      if (!db) return [];
      return db.questions.orderBy("createdAt").reverse().toArray();
    }, []) ?? []
  );
}

export function useAttempts() {
  return (
    useLiveQuery(async () => {
      const db = getDb();
      if (!db) return [];
      return db.attempts.orderBy("createdAt").reverse().toArray();
    }, []) ?? []
  );
}

export function useMistakes() {
  return (
    useLiveQuery(async () => {
      const db = getDb();
      if (!db) return [];
      return db.mistakes.orderBy("createdAt").reverse().toArray();
    }, []) ?? []
  );
}

export function useRevisions() {
  return (
    useLiveQuery(async () => {
      const db = getDb();
      if (!db) return [];
      return db.revisionItems.toArray();
    }, []) ?? []
  );
}

export function useNotes() {
  return (
    useLiveQuery(async () => {
      const db = getDb();
      if (!db) return [];
      return db.notes.orderBy("updatedAt").reverse().toArray();
    }, []) ?? []
  );
}

export function useFormulas() {
  return (
    useLiveQuery(async () => {
      const db = getDb();
      if (!db) return [];
      return db.formulas.toArray();
    }, []) ?? []
  );
}

export function useConcepts() {
  return (
    useLiveQuery(async () => {
      const db = getDb();
      if (!db) return [];
      return db.concepts.toArray();
    }, []) ?? []
  );
}

export function useConceptLinks() {
  return (
    useLiveQuery(async () => {
      const db = getDb();
      if (!db) return [];
      return db.conceptLinks.toArray();
    }, []) ?? []
  );
}

export function useMocks() {
  return (
    useLiveQuery(async () => {
      const db = getDb();
      if (!db) return [];
      return db.mocks.orderBy("createdAt").reverse().toArray();
    }, []) ?? []
  );
}

export function useMockResults() {
  return (
    useLiveQuery(async () => {
      const db = getDb();
      if (!db) return [];
      return db.mockResults.orderBy("submittedAt").reverse().toArray();
    }, []) ?? []
  );
}

export function useSessions() {
  return (
    useLiveQuery(async () => {
      const db = getDb();
      if (!db) return [];
      return db.studySessions.orderBy("startedAt").reverse().toArray();
    }, []) ?? []
  );
}

export function useSettingsLive() {
  return useLiveQuery(async () => {
    const db = getDb();
    if (!db) return undefined;
    return getSettings();
  }, []);
}

export function useHighlights(bookId: string | undefined) {
  return (
    useLiveQuery(async () => {
      if (!bookId) return [];
      const db = getDb();
      if (!db) return [];
      return db.highlights.where("bookId").equals(bookId).toArray();
    }, [bookId]) ?? []
  );
}

export function useBookmarks(bookId: string | undefined) {
  return (
    useLiveQuery(async () => {
      if (!bookId) return [];
      const db = getDb();
      if (!db) return [];
      return db.bookmarks.where("bookId").equals(bookId).sortBy("page");
    }, [bookId]) ?? []
  );
}

export function useKnowledgeMap() {
  const topics = useTopics();
  const attempts = useAttempts();
  const mistakes = useMistakes();
  const revisions = useRevisions();
  const questions = useQuestions();

  return useMemo(() => {
    const qByTopic = new Map<string, Set<string>>();
    for (const q of questions) {
      if (!q.topicId) continue;
      const set = qByTopic.get(q.topicId) ?? new Set();
      set.add(q.id);
      qByTopic.set(q.topicId, set);
    }
    const map: Record<string, number> = {};
    for (const topic of topics) {
      const ids = qByTopic.get(topic.id);
      const atts = ids ? attempts.filter((a) => ids.has(a.questionId)) : [];
      const ms = mistakes.filter((m) => m.topicId === topic.id);
      const rs = revisions.filter((r) => r.topicId === topic.id || (r.kind === "topic" && r.refId === topic.id));
      map[topic.id] = topicKnowledge({ topic, attempts: atts, mistakes: ms, revisions: rs });
    }
    return map;
  }, [topics, attempts, mistakes, revisions, questions]);
}

export function useReadiness(): ReadinessBreakdown[] {
  const exams = useExams();
  const topics = useTopics();
  const knowledge = useKnowledgeMap();
  const attempts = useAttempts();
  const questions = useQuestions();
  const revisions = useRevisions();
  const mockResults = useMockResults();
  const mocks = useMocks();
  const settings = useSettingsLive();

  return useMemo(() => {
    const mockExam = new Map(mocks.map((m) => [m.id, m.examId]));
    return exams.map((exam) => {
      const examMockResults = mockResults.filter((r) => mockExam.get(r.mockId) === exam.id);
      return examReadiness({
        exam,
        topics,
        knowledgeByTopic: knowledge,
        attempts,
        questions,
        revisions,
        mockResults: examMockResults,
        weights: settings?.readinessWeights,
        targetMs: settings?.targetTimes[exam.id],
      });
    });
  }, [exams, topics, knowledge, attempts, questions, revisions, mockResults, mocks, settings]);
}
