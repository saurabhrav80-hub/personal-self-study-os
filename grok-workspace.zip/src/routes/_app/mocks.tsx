import { createFileRoute } from "@tanstack/react-router";
import { MocksPage } from "@/features/mocks-page";

export const Route = createFileRoute("/_app/mocks")({
  component: MocksPage,
});
