import { createFileRoute } from "@tanstack/react-router";
import { InsightsPage } from "@/features/insights-page";

export const Route = createFileRoute("/_app/insights")({
  component: InsightsPage,
});
