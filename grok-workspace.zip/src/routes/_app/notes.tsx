import { createFileRoute } from "@tanstack/react-router";
import { NotesListPage } from "@/features/notes-page";

export const Route = createFileRoute("/_app/notes")({
  component: NotesListPage,
});
