import { createFileRoute } from "@tanstack/react-router";
import { MockReportPage } from "@/features/mock-report-page";

export const Route = createFileRoute("/_app/mocks/report/$resultId")({
  component: Page,
});

function Page() {
  const { resultId } = Route.useParams();
  return <MockReportPage resultId={resultId} />;
}
