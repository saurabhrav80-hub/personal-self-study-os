import { createFileRoute } from "@tanstack/react-router";
import { QuestionNewPage } from "@/features/question-new-page";

export const Route = createFileRoute("/_app/questions/new")({
  component: QuestionNewPage,
});
