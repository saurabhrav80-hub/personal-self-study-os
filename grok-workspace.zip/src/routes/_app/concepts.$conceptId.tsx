import { createFileRoute } from "@tanstack/react-router";
import { ConceptDetailPage } from "@/features/concepts-page";

export const Route = createFileRoute("/_app/concepts/$conceptId")({
  component: Page,
});

function Page() {
  const { conceptId } = Route.useParams();
  return <ConceptDetailPage conceptId={conceptId} />;
}
