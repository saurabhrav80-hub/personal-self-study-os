import { createFileRoute } from "@tanstack/react-router";
import { NoteEditorPage } from "@/features/note-editor-page";

export const Route = createFileRoute("/_app/notes/$noteId")({
  component: Page,
});

function Page() {
  const { noteId } = Route.useParams();
  return <NoteEditorPage noteId={noteId} />;
}
