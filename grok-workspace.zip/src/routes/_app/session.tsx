import { createFileRoute } from "@tanstack/react-router";
import { SessionPage } from "@/features/session-page";

export const Route = createFileRoute("/_app/session")({
  component: SessionPage,
});
