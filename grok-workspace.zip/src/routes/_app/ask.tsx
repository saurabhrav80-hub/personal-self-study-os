import { createFileRoute } from "@tanstack/react-router";
import { AskPage } from "@/features/ask-page";

export const Route = createFileRoute("/_app/ask")({
  component: AskPage,
});
