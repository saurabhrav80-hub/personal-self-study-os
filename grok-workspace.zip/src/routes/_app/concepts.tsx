import { createFileRoute } from "@tanstack/react-router";
import { ConceptsPage } from "@/features/concepts-page";

export const Route = createFileRoute("/_app/concepts")({
  component: ConceptsPage,
});
