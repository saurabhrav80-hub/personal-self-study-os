import { createFileRoute } from "@tanstack/react-router";
import { MistakesPage } from "@/features/mistakes-page";

export const Route = createFileRoute("/_app/mistakes")({
  component: MistakesPage,
});
