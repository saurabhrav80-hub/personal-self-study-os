import { createFileRoute } from "@tanstack/react-router";
import { RevisionPage } from "@/features/revision-page";

export const Route = createFileRoute("/_app/revision")({
  component: RevisionPage,
});
