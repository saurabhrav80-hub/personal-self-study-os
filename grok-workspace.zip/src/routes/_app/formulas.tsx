import { createFileRoute } from "@tanstack/react-router";
import { FormulasPage } from "@/features/formulas-page";

export const Route = createFileRoute("/_app/formulas")({
  component: FormulasPage,
});
