import { createFileRoute } from "@tanstack/react-router";
import { BookPage } from "@/features/book-page";

export const Route = createFileRoute("/_app/library/$bookId")({
  component: BookDetail,
});

function BookDetail() {
  const { bookId } = Route.useParams();
  return <BookPage bookId={bookId} />;
}
