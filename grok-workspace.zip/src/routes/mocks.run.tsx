import { createFileRoute } from "@tanstack/react-router";
import { MockRunPage } from "@/features/mock-run-page";

type Search = { mockId?: string };

export const Route = createFileRoute("/mocks/run")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    mockId: s.mockId ? String(s.mockId) : undefined,
  }),
  component: Page,
});

function Page() {
  const { mockId } = Route.useSearch();
  return <MockRunPage mockId={mockId ?? ""} />;
}
