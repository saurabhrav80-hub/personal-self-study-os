import { createFileRoute } from "@tanstack/react-router";
import { PracticeRunPage, type PracticeSearch } from "@/features/practice-run-page";
import type { Difficulty } from "@/lib/study/types";

export const Route = createFileRoute("/practice/run")({
  validateSearch: (s: Record<string, unknown>): PracticeSearch => ({
    mode: s.mode ? String(s.mode) : undefined,
    examId: s.examId ? String(s.examId) : undefined,
    topicId: s.topicId ? String(s.topicId) : undefined,
    difficulty: s.difficulty ? (String(s.difficulty) as Difficulty) : undefined,
    timed: s.timed ? String(s.timed) : undefined,
    count: s.count ? String(s.count) : undefined,
    questionId: s.questionId ? String(s.questionId) : undefined,
    sessionId: s.sessionId ? String(s.sessionId) : undefined,
  }),
  component: Page,
});

function Page() {
  const search = Route.useSearch();
  return <PracticeRunPage search={search} />;
}
