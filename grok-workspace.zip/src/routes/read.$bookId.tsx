import { createFileRoute } from "@tanstack/react-router";
import { ReaderPage } from "@/features/reader-page";

type Search = { page?: number };

export const Route = createFileRoute("/read/$bookId")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    page: s.page != null ? Number(s.page) : undefined,
  }),
  component: Page,
});

function Page() {
  const { bookId } = Route.useParams();
  const { page } = Route.useSearch();
  return <ReaderPage bookId={bookId} initialPage={page} />;
}
