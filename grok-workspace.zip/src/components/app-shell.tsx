import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import { BookOpen, House, LineChart, ListChecks, RotateCcw, Search, Settings, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Home", icon: House },
  { to: "/library", label: "Library", icon: BookOpen },
  { to: "/practice", label: "Practice", icon: ListChecks },
  { to: "/revision", label: "Review", icon: RotateCcw },
  { to: "/insights", label: "Insights", icon: LineChart },
] as const;

export function AppShell() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="sticky top-0 z-40 border-b border-border bg-bg/90 backdrop-blur-sm">
        <div className="mx-auto flex h-14 max-w-5xl items-center justify-between gap-3 px-4">
          <Link to="/" className="flex items-baseline gap-2">
            <span className="font-display text-lg font-medium tracking-tight">Study OS</span>
            <span className="hidden text-[11px] tracking-wide text-subtle sm:inline">Self-study</span>
          </Link>
          <div className="flex items-center gap-0.5">
            <IconLink to="/search" label="Search" current={pathname.startsWith("/search")}>
              <Search className="size-5" />
            </IconLink>
            <IconLink to="/ask" label="Ask my books" current={pathname.startsWith("/ask")}>
              <Sparkles className="size-5" />
            </IconLink>
            <IconLink to="/settings" label="Settings" current={pathname.startsWith("/settings")}>
              <Settings className="size-5" />
            </IconLink>
          </div>
        </div>
      </header>

      <main>
        <Outlet />
      </main>

      <nav
        className="fixed right-0 bottom-0 left-0 z-40 border-t border-border bg-bg/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm"
        aria-label="Primary"
      >
        <div className="mx-auto grid h-16 max-w-lg grid-cols-5">
          {NAV.map((item) => {
            const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex min-h-11 flex-col items-center justify-center gap-0.5 text-[11px] font-medium",
                  active ? "text-fg" : "text-subtle",
                )}
              >
                <Icon className="size-5" strokeWidth={active ? 2.2 : 1.7} />
                {item.label}
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

function IconLink({
  to,
  label,
  current,
  children,
}: {
  to: string;
  label: string;
  current: boolean;
  children: React.ReactNode;
}) {
  return (
    <Link
      to={to}
      aria-label={label}
      className={cn(
        "flex size-11 items-center justify-center rounded-lg",
        current ? "text-fg" : "text-muted hover:bg-surface-2 hover:text-fg",
      )}
    >
      {children}
    </Link>
  );
}
