import { Badge } from "@/components/ui/badge";
import { TOPIC_STATUS_LABEL, type TopicStatus } from "@/lib/study/types";

export function StatusChip({ status }: { status: TopicStatus }) {
  const tone =
    status === "mastered" || status === "strong"
      ? "good"
      : status === "not_started"
        ? "muted"
        : status === "revised" || status === "practiced"
          ? "ink"
          : "warn";
  return <Badge tone={tone}>{TOPIC_STATUS_LABEL[status]}</Badge>;
}

export function KnowledgeBar({ score }: { score: number }) {
  return (
    <div className="flex items-center gap-2">
      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-surface-2">
        <div
          className="h-full rounded-full bg-ink"
          style={{ width: `${Math.max(0, Math.min(100, score))}%` }}
        />
      </div>
      <span className="tabular w-10 text-right text-xs text-muted">{Math.round(score)}%</span>
    </div>
  );
}

export function ReadinessRing({ value, size = 56 }: { value: number | null; size?: number }) {
  const r = 18;
  const c = 2 * Math.PI * r;
  const v = value ?? 0;
  const offset = c - (v / 100) * c;
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg viewBox="0 0 44 44" className="size-full -rotate-90">
        <circle cx="22" cy="22" r={r} fill="none" stroke="currentColor" className="text-surface-2" strokeWidth="4" />
        <circle
          cx="22"
          cy="22"
          r={r}
          fill="none"
          stroke="currentColor"
          className="text-ink"
          strokeWidth="4"
          strokeDasharray={c}
          strokeDashoffset={value === null ? c : offset}
          strokeLinecap="round"
        />
      </svg>
      <span className="absolute inset-0 flex items-center justify-center font-display text-sm tabular text-fg">
        {value === null ? "—" : Math.round(value)}
      </span>
    </div>
  );
}
