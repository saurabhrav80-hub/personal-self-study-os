import { cn } from "@/lib/utils";

export function EmptyState({
  title,
  body,
  action,
  className,
}: {
  title: string;
  body: string;
  action?: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("rounded-2xl bg-surface px-5 py-10 text-center shadow-[var(--shadow-border)]", className)}>
      <h3 className="font-display text-lg font-medium tracking-tight text-fg">{title}</h3>
      <p className="mx-auto mt-2 max-w-sm text-sm text-muted">{body}</p>
      {action ? <div className="mt-5 flex justify-center">{action}</div> : null}
    </div>
  );
}

export function Screen({
  children,
  title,
  action,
  wide,
}: {
  children: React.ReactNode;
  title?: string;
  action?: React.ReactNode;
  wide?: boolean;
}) {
  return (
    <div className={cn("mx-auto w-full px-4 pb-28 pt-4 md:px-6", wide ? "max-w-5xl" : "max-w-3xl")}>
      {title ? (
        <header className="mb-5 flex items-end justify-between gap-3">
          <h1 className="font-display text-[1.75rem] font-medium tracking-tight text-fg">{title}</h1>
          {action}
        </header>
      ) : null}
      {children}
    </div>
  );
}

export function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p className="mb-2 text-[11px] font-medium tracking-[0.14em] text-subtle uppercase">{children}</p>
  );
}
