import { useEffect, useState, type ReactNode } from "react";
import { getDb } from "@/lib/study/db";
import { ensureSeeded } from "@/lib/study/seed";
import { useSettingsLive } from "@/lib/study/hooks";

export function StudyBoot({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const db = getDb();
        if (db) await ensureSeeded(db);
        if (!cancelled) setReady(true);
      } catch (e) {
        if (!cancelled) setError(e instanceof Error ? e.message : "Could not open local storage.");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!ready) return;
    const root = document.documentElement;
    const apply = (theme: string) => {
      const dark =
        theme === "dark" ||
        (theme !== "light" && window.matchMedia("(prefers-color-scheme: dark)").matches);
      root.classList.toggle("dark", dark);
    };
    apply(localStorage.getItem("study-os-theme") ?? "system");
  }, [ready]);

  if (error) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-bg px-6 text-center">
        <div>
          <p className="font-display text-xl text-fg">Storage unavailable</p>
          <p className="mt-2 max-w-sm text-sm text-muted">{error}</p>
        </div>
      </div>
    );
  }

  if (!ready) {
    return (
      <div className="flex min-h-dvh flex-col items-center justify-center bg-bg px-6 text-center">
        <p className="font-display text-3xl font-medium tracking-tight text-fg">Study OS</p>
        <p className="mt-2 text-sm text-muted">Opening your local library…</p>
      </div>
    );
  }

  return (
    <>
      <ThemeSync />
      {children}
    </>
  );
}

function ThemeSync() {
  const settings = useSettingsLive();
  useEffect(() => {
    const theme = settings?.theme ?? "system";
    localStorage.setItem("study-os-theme", theme);
    const apply = () => {
      const dark =
        theme === "dark" ||
        (theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
      document.documentElement.classList.toggle("dark", dark);
    };
    apply();
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, [settings?.theme]);
  return null;
}
