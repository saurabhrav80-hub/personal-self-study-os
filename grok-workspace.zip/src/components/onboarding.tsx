import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAllExams, useSettingsLive } from "@/lib/study/hooks";
import { createExam, patchSettings, updateExam } from "@/lib/study/repo";

export function Onboarding() {
  const settings = useSettingsLive();
  const exams = useAllExams();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [other, setOther] = useState("");
  const [name, setName] = useState("");

  if (settings?.onboardingComplete) return null;
  if (!settings) return null;

  const toggle = async (id: string, on: boolean) => {
    await updateExam(id, { active: on });
  };

  const finish = async () => {
    if (other.trim()) await createExam({ name: other.trim(), priority: 3 });
    if (name.trim()) await patchSettings({ displayName: name.trim(), onboardingComplete: true });
    else await patchSettings({ onboardingComplete: true });
    navigate({ to: "/library" });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-bg px-5 py-12">
      <div className="mx-auto max-w-md">
        {step === 0 && (
          <div>
            <p className="text-[11px] font-medium tracking-[0.16em] text-subtle uppercase">Welcome</p>
            <h1 className="mt-3 font-display text-4xl font-medium tracking-tight text-fg">
              Personal Self-Study OS
            </h1>
            <p className="mt-4 text-base text-muted">
              Study smarter. Remember longer. Perform better.
            </p>
            <p className="mt-4 text-sm text-muted">
              A local learning system for converting books into practice, revision, mocks, and exam
              readiness. Nothing here requires an account. Your data stays on this device.
            </p>
            <Button className="mt-8 w-full" size="lg" onClick={() => setStep(1)}>
              Continue
            </Button>
          </div>
        )}

        {step === 1 && (
          <div>
            <p className="text-[11px] font-medium tracking-[0.16em] text-subtle uppercase">Exams</p>
            <h2 className="mt-3 font-display text-3xl font-medium tracking-tight">What are you preparing for?</h2>
            <p className="mt-2 text-sm text-muted">You can add or remove exams later.</p>
            <ul className="mt-6 space-y-2">
              {exams.map((e) => (
                <li key={e.id}>
                  <label className="flex min-h-14 cursor-pointer items-center justify-between rounded-2xl bg-surface px-4 shadow-[var(--shadow-border)]">
                    <span className="font-medium">{e.name}</span>
                    <input
                      type="checkbox"
                      className="size-5 accent-ink"
                      checked={e.active}
                      onChange={(ev) => toggle(e.id, ev.target.checked)}
                    />
                  </label>
                </li>
              ))}
            </ul>
            <div className="mt-4">
              <Input
                placeholder="Other exam or course"
                value={other}
                onChange={(e) => setOther(e.target.value)}
              />
            </div>
            <div className="mt-8 flex gap-2">
              <Button variant="ghost" className="flex-1" onClick={() => setStep(0)}>
                Back
              </Button>
              <Button className="flex-1" onClick={() => setStep(2)}>
                Continue
              </Button>
            </div>
          </div>
        )}

        {step === 2 && (
          <div>
            <p className="text-[11px] font-medium tracking-[0.16em] text-subtle uppercase">You</p>
            <h2 className="mt-3 font-display text-3xl font-medium tracking-tight">Optional name</h2>
            <p className="mt-2 text-sm text-muted">Used only for the greeting. Stored locally.</p>
            <Input
              className="mt-6"
              placeholder="First name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
            <div className="mt-8 flex flex-col gap-2">
              <Button size="lg" onClick={finish}>
                Add books and start
              </Button>
              <Button
                variant="ghost"
                onClick={async () => {
                  await patchSettings({ onboardingComplete: true, displayName: name.trim() });
                  navigate({ to: "/" });
                }}
              >
                Skip for now
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
